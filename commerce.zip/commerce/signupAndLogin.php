<?php
 session_start();
 spl_autoload_register(function($class){
     include "core/".$class.".php";
 });
 
 $db = new db;
if(isset($_SESSION['user'])){
    header("location:index");
}


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login or Sign up </title>
    <link rel="stylesheet" href="css/font-awesome.min.css">
    <link rel="stylesheet" href="css/slick.css">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/media.css">
</head>
<body>
<?php include 'partials/navbar.php';?>
  
    <!-- ------ haeder area or navber area ------  -->
    <!-- <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <div class="container-fluid">
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
               
              </div>
          <a class="navbar-brand text-start" href="#">Navbar</a>
          <form class="d-flex">
            <input class="form-control" type="search" placeholder="Search" aria-label="Search">
          </form>
          <div class="nav-icons text-end d-flex">
            <i class="gg-search"></i>
            <i class="gg-profile"></i>
            <i class="gg-heart"></i>
            <i class="gg-shopping-bag"></i>
           
          </div>
          <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            </button>
          </button> -->
          <!-- ------ side navbar  -->
          <!-- <aside class="sidebar">
            <div class="toggle">
                <a href="#" class="burger js-menu-toggle" data-toggle="collapse" data-target="#main-navbar">
                   <span></span>
                    </a>
              </div>
            <div class="side-inner">
      
              <div class="navbar-logoName">
                <a href="#">MANGO</a>
                <h3>Lorem ipsum <b>dolor sit.</b></h3>
      
              </div>
              <div class="manu-items">
                <a href="#">
                    <div class="category-img d-flex">
                        <p>Category Name 1</p>
                        <img src="images/categori-man.png" alt="man">
                    </div>
                </a>
              </div>
              <div class="manu-items">
                <a href="#">
                    <div class="category-img d-flex">
                        <p>Category Name 2</p>
                        <img src="images/categori-man.png" alt="man">
                    </div>
                </a>
              </div>
              <div class="manu-items">
                <a href="#">
                    <div class="category-img d-flex">
                        <p>Category Name 3</p>
                        <img src="images/categori-man.png" alt="man">
                    </div>
                </a>
              </div>
              <div class="manu-items">
                <a href="#">
                    <div class="category-img d-flex">
                        <p>Category Name 4</p>
                        <img src="images/categori-man.png" alt="man">
                    </div>
                </a>
              </div>
              <div class="manu-items">
                <a href="#">
                    <div class="category-img d-flex">
                        <p>Category Name 5</p>
                        <img src="images/categori-man.png" alt="man">
                    </div>
                </a>
              </div>
              <div class="manu-items">
                <a href="#">
                    <div class="category-img d-flex">
                        <p>Category Name 6</p>
                        <img src="images/categori-man.png" alt="man">
                    </div>
                </a>
              </div>
              <div class="manu-items">
                <a href="#">
                    <div class="category-img d-flex">
                        <p>Category Name 7</p>
                        <img src="images/categori-man.png" alt="man">
                    </div>
                </a>
              </div>
              <div class="manu-items">
                <a href="#">
                    <div class="category-img d-flex">
                        <p>Category Name 8</p>
                        <img src="images/categori-man.png" alt="man">
                    </div>
                </a>
              </div>
              <div class="manu-items">
                <a href="#">
                    <div class="category-img d-flex">
                        <p>Category Name 9</p>
                        <img src="images/categori-man.png" alt="man">
                    </div>
                </a>
              </div>
  
              <p class="nav-text">
                  Lorem ipsum dolor sit amet consectetur adipisicing elit. Necessitatibus, cumque!
              </p>
            </div>
            
          </aside>
        </div>
      </nav> -->
      <!-- navbar all html end  -->

 <section id="signupAndLogin">
     <div class="container text-center">
         <div class="row">
             <div class="col-lg-12">
                 <div class="SignAndLog">
                    <div class="sAlnav">
                        <ul class="nav nav-tabs nav1" id="myTab" role="tablist">
                            <li class="nav-item" role="presentation">
                              <button class="nav-link nav-color active" id="home-tab" data-bs-toggle="tab" data-bs-target="#home" type="button" role="tab" aria-controls="home" aria-selected="true">Log In</button>
                            </li>
                            <li class="nav-item" role="presentation">
                              <button class="nav-link nav-color" id="profile-tab" data-bs-toggle="tab" data-bs-target="#profile" type="button" role="tab" aria-controls="profile" aria-selected="false">Sign Up</button>
                            </li>
                          </ul>
                    </div>
                      <div class="tab-content" id="myTabContent">
                        <div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">
                            <form method="POST" id="lg" onsubmit="return false;">
                                <div class="conatainer">
                                    <div class="row">
                                        <div class="col-lg-12">
                                            <div class="login-content">
                                                <input type="email" name="email" id="mail" placeholder="E-mail">
                                                <input type="password" name="pass" id="pw" placeholder="Password">
                                                <div class="check-box">
                                                    <input type="checkbox" name="chack" id="check"> <p>Keep me logged in</p>
                                                </div>
                                                <button id="ssub" class="ln" type="submit">Enter</button>
                                                <a href="#">Forgotten your password</a>
                                                <hr>
                                                <p>Don't have an account? <a href="#">Register</a></p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                        <div class="tab-pane fade" id="profile" role="tabpanel" aria-labelledby="profile-tab">
                         
                                <div class="conatainer">
                                    <form method="POST" id="frm" class="row" onsubmit="return false;">
                                    <div class="row">
                                        <div class="col-lg-12">
                                            <div class="login-content">
                                                    <div class="d-flex">
                                                        <input type="text" name="fName" id="fn" placeholder="First Name*">
                                                    <input type="text" class="lName" name="lName" id="ln" placeholder="Last Name*">
                                                    </div>
                                                <input type="email" name="email" id="mail" placeholder="E-mail*">
                                                <input type="password" name="pass" id="pw" placeholder="Password*">
                                                <input type="tel" name="phone" id="tel" placeholder="Mobile Number">
                                                <select name="age" id="age">
                                                    <option value="">Age Group*</option>
                                                    <option value="20">Lesss Than 20</option>
                                                    <option value="2125">21-24</option>
                                                    <option value="2529">25-29</option>
                                                    <option value="30">More than 30</option>
                                                </select>
                                                <button type="submit" class="b" id="ssub">Enter</button>
                                            </div>
                                        </div>
                                    </div>
                                    </form>
                                </div>
  
                            <!-- <form action="#">
                                <div class="container">
                                    <div class="row">
                                        <div class="col-lg-12">
                                            <div class="sign-content">
                                                <div class="s-name">
                                                <input type="text" name="fName" id="fn" placeholder="First Name*">
                                                <input type="text" class="lName" id="ln" placeholder="Last Name*">
                                                </div>
                                                <input type="email" name="mail" id="mail" placeholder="E-mail*">
                                                <input type="password" name="password" id="pw" placeholder="Password*">
                                                <input type="tel" name="number" id="tel" placeholder="Mobile Number">
                                                <select name="age" id="age">
                                                    <option value="">Age Group*</option>
                                                    <option value="20">Lesss Than 20</option>
                                                    <option value="2125">21-24</option>
                                                    <option value="2529">25-29</option>
                                                    <option value="30">More than 30</option>
                                                </select>
                                                <button type="submit" id="ssub">Enter</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </form> -->
                        </div>
                      </div>
                 </div>
             </div>
         </div>
     </div>
 </section>
  <!-- --------------------- footer area  -->
  <footer id="footer-area mt-3">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="pay-card text-center">
                    <i class="fa fa-paypal" aria-hidden="true"></i>
                    <i class="fa fa-cc-amex" aria-hidden="true"></i>
                    <i class="fa fa-cc-visa" aria-hidden="true"></i>
                    <i class="fa fa-cc-mastercard" aria-hidden="true"></i>
                    <i class="fa fa-credit-card-alt" aria-hidden="true"></i>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-12">
                <div class="copyright-text text-center">
                    <p>Copyright &copy; 2021 - Mengo .All Rights Reserved </p>
                </div>
            </div>
        </div>
    </div>
  </footer>

         <!-- all javascript link  -->
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery-1.12.4.min.js"></script>
    <script src="js/slick.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/custom.js"></script>
    <script src="js/nav.js"></script>
    <script src="js/user.js"></script>
</body>
</html>