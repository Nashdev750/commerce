<?php
session_start();
spl_autoload_register(function($class){
    include $class.".php";
});

$db = new db;

$sql="SELECT * FROM `cart` WHERE `cartid`='".$_SESSION['cart']."'";

$cart = $db->readdbone($sql);

$cartitms = json_decode($cart['items'],true);

$details = array();

$count = 0;
$index = -1;
foreach ($cartitms as $itm) {
      if($itm['id']== $_GET['id'] && $itm['color']== $_GET['color'] && $itm['size']== $_GET['size']){
       $index = $count;
      }
      $count++;
}

if($index > -1){
    unset($cartitms[$index]);
    
    $q = "UPDATE `cart` SET `items`='".json_encode(array_values($cartitms))."' WHERE cartid='".$_SESSION['cart']."'";
    $db->writebd($q);
    echo "removed";
}