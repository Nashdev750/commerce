<?php

session_start();

function __autoload($class){
    include $class.".php";
}

$db = new db;

$sql = "INSERT INTO `messages`(`sender`, `receiver`, `msg`, `msgid`) VALUES (:sender,:receiver,:msg,:msgid)";
$uid = "";
$uidd = $db->readdbone("SELECT * FROM `messages` WHERE sender=".$_SESSION['family']['id']." AND receiver =".$_SESSION['chat']."");
if(empty($uidd['msgid'])){
    $uidd = $db->readdbone("SELECT * FROM `messages` WHERE sender=".$_SESSION['chat']." AND receiver =".$_SESSION['family']['id']."");
}
  $uid = $uidd['msgid'];
 

     if(empty($uid)){
         $uid = uniqid();
     }
    if(empty($_FILES['pic']['name'])){
        $arr = array('sender'=>$_SESSION['family']['id'],'receiver'=>$_SESSION['chat'],'msg'=>$_POST['messag'],"msgid"=>$uid);
        $ch =  $db->writebd($sql,$arr);
       if($ch==1){
           echo 1;
       }
    }elseif(!empty($_FILES['pic']['name'])){
        $sql = "INSERT INTO `messages`(`sender`, `receiver`, `msg`,`media`, `msgid`) VALUES (:sender,:receiver,:msg,:media,:msgid)";
        //,'NEF','nef','mp4','MP4','mkv','MKV'
        $ext = array('jpg','png','jpeg','JPEG','JPG','PNG');
        $name = $_FILES['pic']['name'];
        $extens = explode(".",$name);
    
        if(!in_array($extens[1],$ext)){
            echo 3;
          return;
        }elseif(in_array($extens[1],$ext)){
          
        $newname = uniqid(time()).$extens[0].$_SESSION['family']['id'].".".$extens[1];
        if(move_uploaded_file($_FILES['pic']['tmp_name'],'../images/chat/'.$newname)){

            $arr = array('sender'=>$_SESSION['family']['id'],'receiver'=>$_SESSION['chat'],'msg'=>$_POST['messag'],'media'=>$newname,"msgid"=>$uid);
            $ch =  $db->writebd($sql,$arr);
           if($ch==1){
               echo 1;
           }
        }  
    }
 }
 
