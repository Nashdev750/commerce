<?php
session_start();
function __autoload($class){
    include $class.".php";
}


    $db = new db;

    if(empty($_POST['name']) || empty($_FILES['file']['name'])){
      echo 9;
    }else{
        $sql="UPDATE `users` SET `name`=:name,`profile`=:img WHERE `id`=:id";
        $data=array('name'=>$_POST['name'],'img'=>"pic",'id'=>$_SESSION['family']['id']);
        $ck = $db->uploadimg($_FILES['file'],$sql,$data,"../images/");
        
          echo $ck;

    }
  