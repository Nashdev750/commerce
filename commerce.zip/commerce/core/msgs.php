<?php

    session_start();

    function __autoload($class){
        include $class.".php";
    }

    $db = new db;

  

    $uid = "0";
    $uidd = $db->readdbone("SELECT * FROM `messages` WHERE sender=".$_SESSION['family']['id']." AND receiver =".$_SESSION['chat']."");
    if(empty($uidd['msgid'])){
        $uidd = $db->readdbone("SELECT * FROM `messages` WHERE sender=".$_SESSION['chat']." AND receiver =".$_SESSION['family']['id']."");
    }
    
    $uid = $uidd['msgid'];
    $id = 0;
    $msgs = $db->readdb("SELECT * FROM `messages` WHERE msgid='".$uid."' AND id > ".$_SESSION['start']."");
     
    $data = array();
    foreach($msgs as $msg){
        $side = "0";
        $img="def.jpg";
        if($msg['sender']==$_SESSION['family']['id']){
            $side = "1";
        }
       
           $img = $db->readname("SELECT profile FROM users WHERE id='{$msg['sender']}'","profile"); 
        
         date_default_timezone_set("Africa/Nairobi");
         $tm = explode(":",explode(" ",$msg['sentat'])[1]);
           $ms = array("side"=>$side,"msg"=>$msg['msg'],"tim"=>$tm[0].":".$tm[1],"media"=>$msg['media'],'img'=>str_replace("'","",$img),'seen'=>$msg['seen']);
           array_push($data,$ms);
           $_SESSION['start'] = $msg['id'];

        }
    echo json_encode($data);
    