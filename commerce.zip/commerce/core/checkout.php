<?php
session_start();
spl_autoload_register(function($class){
    include $class.".php";
});

$db = new db;

$sql="SELECT * FROM `cart` WHERE `cartid`='".$_SESSION['cart']."'";

$cart = $db->readdbone($sql);

$cartitms = json_decode($cart['items'],true);

if($cart){

}else{
    unset($_SESSION['cart']);
}
$details = array();

foreach ($cartitms as $itm) {
    $name =$db->readname("SELECT p_name FROM products WHERE id='".$itm['id']."'","p_name");
    $image=$db->readname("SELECT image FROM products WHERE id='".$itm['id']."'","image");
    $price=$db->readname("SELECT price FROM products WHERE id='".$itm['id']."'","price");

    array_push($details,array('id'=>$itm['id'],'name'=>$name,'color'=>$itm['color'],'image'=>$image,'price'=>$price,'qty'=>$itm['qty'],'size'=>$itm['size']));
}

echo json_encode($details);