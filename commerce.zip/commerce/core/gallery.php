
<?php
// include php classes
session_start();

spl_autoload_register(function($class){
    include_once $class.".php";
 });
 $db = new db;


 if(isset($_FILES['images']['name'])){
    $rep =  $db->uploadimg($_FILES['images'],"../userimg/gallery/");
    if($rep !=3){
       $pic = $db->readdbone("SELECT pic FROM profile WHERE userid={$_SESSION['user']['id']}");
   
       $newpic = $pic['pic']." ".$rep;
       $db->writebd("UPDATE `profile` SET `pic`='".$newpic."' WHERE `userid` ={$_SESSION['user']['id']}");
    }
    echo  $rep;
 }