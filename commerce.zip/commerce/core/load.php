<?php

spl_autoload_register(function($class){
    include $class.".php";
});

$db = new db;
 $products = $db->readdb($_GET['q']);
 $json = array();
 foreach($products as $product){
   array_push($json,array('id'=> $product['id'],'pname'=>$product['p_name'],'price'=>$product['price'],'image'=>$product['image']));
 }
 header("content-type:applicatio/json");
 echo json_encode($json);
 