<?php
session_start();
spl_autoload_register(function($class){
    include $class.".php";
});

$db = new db;

$cartitems = array();
if(!isset($_SESSION['cart'])){
 addnew($db,$cartitems);
   
}else{
    $id= $_SESSION['cart'];
    $cart = $db->readdbone("SELECT * FROM `cart` WHERE `cartid`='".$id."'");
    if(!$cart){
        addnew($db,$cartitems);
    }else{
        
        $elm = explode("-",$_GET['id']);
       $cartitm = json_decode($cart['items'],true);
       $t = false;
       foreach ($cartitm as $cart) {
           if($cart['id']== $elm[0] && $cart['color']== $elm[1] &&  $cart['size']== $elm[2] ){
            $t = true;
           }
       }
       if($t){
           echo "product already in cart";
       }else{
        array_push( $cartitm,array('id'=>$elm[0],'color'=>$elm[1],'size'=>$elm[2],'qty'=>1));
             
        $q = "UPDATE `cart` SET `items`='".json_encode($cartitm)."' WHERE cartid='".$id."'";

        $db->writebd($q);
        echo "added";
        $t = false;
       }
    }
    
}

function addnew($db,$cartitems){
  
    $_SESSION["cart"] = uniqid(time());
    $elm = explode("-",$_GET['id']);
    array_push($cartitems,array('id'=>$elm[0],'color'=>$elm[1],'size'=>$elm[2],'qty'=>1));
    $sql ="INSERT INTO `cart`(`cartid`, `items`) VALUES (:cartid,:itms)";
    $data = array('cartid'=>$_SESSION['cart'],'itms'=>json_encode($cartitems));
    $k = $db->writebd($sql,$data);
    if($k){
        echo "added";
        
    }else{
        echo "error";
    }
}
