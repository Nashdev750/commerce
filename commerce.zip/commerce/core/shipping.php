<?php
session_start();
spl_autoload_register(function($class){
    include $class.".php";
});

$db = new db;

$userid = isset($_SESSION['user'])?$_SESSION['user']['id']:0;
$orderid = isset($_SESSION['cart'])?$_SESSION['cart']:0;

$country = $_POST['country'];
$name = $_POST['fname'];
$address = $_POST['adress1'];
$adres = ($_POST['adress2']=="")?"Optional":$_POST['adress2'];
$post = $_POST['post'];
$city = $_POST['city'];
$state = $_POST['state'];
$phone = $_POST['phone'];
$emal = $_POST['email'];


if(empty($country) || empty($name) || empty($address) || empty($post) || empty($city) || empty($state) || empty($phone) || empty($emal)){
 echo "Fill out all details";
}else{
    $ct = $db->readdbrow("SELECT * FROM `shipping_detalis` WHERE orderid='".$_SESSION['cart']."'");
    $sql = "INSERT INTO `shipping_detalis`(`userid`, `orderid`, `country`, `fullname`, `adress1`, `adress2`, `postcode`, `city`, `state`, `phone`, `email`)
     VALUES (:userid,:orderid,:country,:fullname,:adress1,:adress2,:post,:city,:state,:phone,:email)";
     $data = array('userid'=>$userid,'orderid'=>$orderid,'country'=>$country,'fullname'=>$name,'adress1'=>$address,'adress2'=>$adres,'post'=>$post,'city'=>$city,'state'=>$state,'phone'=>$phone,'email'=>$emal);
    if($ct==1){
      $sql = "UPDATE `shipping_detalis` SET `userid`=:userid,`country`=:country,`fullname`=:fullname
      ,`adress1`=:adress1,`adress2`=:adress2,`postcode`=:post,
      `city`=:city,`state`=:state,`phone`=:phone,`email`=:email WHERE `orderid`=:orderid";  
       $data = array('userid'=>$userid,'country'=>$country,'fullname'=>$name,'adress1'=>$address,'adress2'=>$adres,'post'=>$post,'city'=>$city,'state'=>$state,'phone'=>$phone,'email'=>$emal,'orderid'=>$orderid);
      
    }

        $ch = $db->writebd($sql,$data);
        if($ch){
            echo "save";
        }else{
          echo $ch;
        
    }

     
}