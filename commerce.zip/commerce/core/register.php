<?php
 function __autoload($class){
    include $class.".php";
}

$db = new db;


if(empty($_POST['lName']) ||empty($_POST['phone']) ||empty($_POST['age']) || empty($_POST['email']) || empty($_POST['pass']) || empty($_POST['fName'])){
    echo "All fields are required";
}elseif(!filter_var($_POST['email'],FILTER_VALIDATE_EMAIL)){
    echo "ivalid email"; 
}elseif(strlen($_POST['pass'])<6){
    echo "password should be 6 char or above";
}else{
    $name = $_POST['fName']." ".$_POST['lName'];
    $pss = password_hash($_POST['pass'],PASSWORD_DEFAULT);
    $sql="INSERT INTO `users`(`fullname`, `email`, `phone`, `password`, `age`, `token`)
     VALUES (:name,:email,:phone,:pass,:age,:token)";
    $data = array('name'=>$name,'email'=>$_POST['email'],'phone'=>$_POST['phone'],'pass'=>$pss,'age'=>$_POST['age'],
    'token'=>password_hash($_POST['email'].$_POST['pass'],PASSWORD_BCRYPT));
    $check = $db->writebd($sql,$data);
    if($check){
       echo "Account created login";
    }else{
       echo "Email alredy exist, login or recover your account";
    }
}
