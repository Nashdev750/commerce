
<?php
session_start();
function __autoload($class){
    include $class.".php";
}


    $email = $_POST['email'];
    $pass = $_POST['pass'];

    $db = new db;

  $re = $db->loginadmin($email,$pass);

   if(isset($_SESSION['user'])){
       echo 2; 
   }else{
       echo 1;
   }
 


