<?php
session_start();
if(isset($_GET['a'])){
    $_SESSION['quiz']['quizc']=trim($_GET['a']);
    echo "next";
}else{
    echo "answer not set";
}