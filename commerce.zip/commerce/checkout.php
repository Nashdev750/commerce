<!-- <?php
spl_autoload_register(function($class){
    include "core/".$class.".php";
});
$db = new db;
$cart = array();
  if(isset($_SESSION['cart'])){
    $sql="SELECT * FROM `cart` WHERE `cartid`='".$_SESSION['cart']."'";

   $cart = $db->readdbone($sql);
  }


?> -->

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cart Page </title>
    <link rel="stylesheet" href="css/font-awesome.min.css">
    <link rel="stylesheet" href="css/slick.css">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/media.css">
    <style>
     .b{
       border:1px solid Black;
     
       transition:.4s all;
     }
     body{
       background:whitesmoke;
     }
     footer{
       background:Black
     }
     .table{
       background:White;
       padding:20px
     }
     .item{
       display:flex;
       padding:10px
     }
     .item img:first-child{
       object-fit:cover;
       width:120px;
       max-height:150px;
     }
     .item div{
       padding:0 14px
     }
     .summary{
       width:100%;
       background:White;
       padding:20px;
       position: fixed;
       max-width: 290px;

     }
     .summary p{
       display:flex;
       justify-content:space-between;
       width:100%
     }
     .row{
      flex-wrap: wrap;
     }
     .form{
       background-color: white;
       padding: 20px;
     }
     .form form button{
       background-color: black;
       font-weight: 500;
       color: white;
       padding: 10px;
       margin: 20px 0;
       width: 200px;
       text-align: center;
     }
     #btn{
      background-color: black;
       font-weight: 500;
       color: white;
       padding: 10px;
       margin: 20px 0;
       width: 200px;
       text-align: center;
     }
     .s{
      background-color: black;
       font-weight: 500;
       color: white;
       padding: 10px;
       margin: 20px 0;
       width: 200px;
       text-align: center;
     }
     .d{
       display: none;
     }
     @media(max-width:500px){
       .summary{
         position: relative;
         width: 100% !important;
         max-width: 500px;
       }
       .col-8,.col-4{
         width:100%;
           
           }
      .table table{
        width:100%
      }  
      .table table tr{
        width:100%;
        display:flex;
        flex-wrap:wrap;
      }   
      .table table tr th{
        display:none
      } 
      .table table tr td{
        width:25%;
        display:flex;
        flex-wrap:wrap;
      }  
      .table table tr td:first-child{
        width:100%;
        display:flex;
        flex-wrap:wrap;
      }  
      .form-control{
        display: inline !important;
      }
     }
    </style>
</head>
<body>
   
<?php include 'partials/navbar.php';?>
    <!-- ------ haeder area or navber area ------  -->
    <!-- <nav class="navbar navbar-expand-lg navbar-light bg-light">
      <div class="container-fluid">
          <div class="collapse navbar-collapse" id="navbarSupportedContent">
             
            </div>
        <a class="navbar-brand text-start" href="#">Navbar</a>
        <form class="d-flex">
          <input class="form-control" type="search" placeholder="Search" aria-label="Search">
        </form>
        <div class="nav-icons text-end d-flex">
          <i class="gg-search"></i>
          <i class="gg-profile"></i>
          <i class="gg-heart"></i>
          <i class="gg-shopping-bag"></i>
         
        </div>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
          </button>
        </button> -->
        <!-- ------ side navbar  -->
        <!-- <aside class="sidebar">
          <div class="toggle">
              <a href="#" class="burger js-menu-toggle" data-toggle="collapse" data-target="#main-navbar">
                 <span></span>
                  </a>
            </div>
          <div class="side-inner">
    
            <div class="navbar-logoName">
              <a href="#">MANGO</a>
              <h3>Lorem ipsum <b>dolor sit.</b></h3>
    
            </div>
            <div class="manu-items">
              <a href="#">
                  <div class="category-img d-flex">
                      <p>Category Name 1</p>
                      <img src="images/categori-man.png" alt="man">
                  </div>
              </a>
            </div>
            <div class="manu-items">
              <a href="#">
                  <div class="category-img d-flex">
                      <p>Category Name 2</p>
                      <img src="images/categori-man.png" alt="man">
                  </div>
              </a>
            </div>
            <div class="manu-items">
              <a href="#">
                  <div class="category-img d-flex">
                      <p>Category Name 3</p>
                      <img src="images/categori-man.png" alt="man">
                  </div>
              </a>
            </div>
            <div class="manu-items">
              <a href="#">
                  <div class="category-img d-flex">
                      <p>Category Name 4</p>
                      <img src="images/categori-man.png" alt="man">
                  </div>
              </a>
            </div>
            <div class="manu-items">
              <a href="#">
                  <div class="category-img d-flex">
                      <p>Category Name 5</p>
                      <img src="images/categori-man.png" alt="man">
                  </div>
              </a>
            </div>
            <div class="manu-items">
              <a href="#">
                  <div class="category-img d-flex">
                      <p>Category Name 6</p>
                      <img src="images/categori-man.png" alt="man">
                  </div>
              </a>
            </div>
            <div class="manu-items">
              <a href="#">
                  <div class="category-img d-flex">
                      <p>Category Name 7</p>
                      <img src="images/categori-man.png" alt="man">
                  </div>
              </a>
            </div>
            <div class="manu-items">
              <a href="#">
                  <div class="category-img d-flex">
                      <p>Category Name 8</p>
                      <img src="images/categori-man.png" alt="man">
                  </div>
              </a>
            </div>
            <div class="manu-items">
              <a href="#">
                  <div class="category-img d-flex">
                      <p>Category Name 9</p>
                      <img src="images/categori-man.png" alt="man">
                  </div>
              </a>
            </div>

            <p class="nav-text">
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Necessitatibus, cumque!
            </p>
          </div>
          
        </aside>
      </div>
    </nav> -->
    <!-- navbar all html end  -->
  <!-- ------------------------------------------ single-product--------------------------  -->
  <div class="container">
    <div class="row" style="margin-top:120px">
       <div class="col-8">
          <div class="table" >
          <h3>Shopping Cart</h3><hr>
          <table class="table">
            <tr>
               <th>Products</th> <th>Size</th> <th>Quantity</th><th>Total</th> <th></th>
            </tr>
              <tbody class="tbody">
             
              </tbody>
           
            </table>
          </div>
       </div>
         <div class="col-4">
         <div class="summary">
        <h3>Order Summary</h3><hr>
        <p><span id="np"></span> <span id="st"></span></p>
        <p><span><strong>Total price</strong></span> <span><strong id="tp"></strong></span></p>
         
         </div>
         </div>
    </div>
    <?php
     if(isset($_SESSION['cart'])){
      $data = $db->readdbone("SELECT * FROM `shipping_detalis` WHERE orderid='".$_SESSION['cart']."'");
      $ct = $db->readdbrow("SELECT * FROM `shipping_detalis` WHERE orderid='".$_SESSION['cart']."'");


        $country = isset($data['country'])? $data['country']:"";
        $name = isset($data['fullname'])? $data['fullname']:(isset($_SESSION['user'])? $_SESSION['user']['fullname']:"");
        $address = isset($data['adress1'])? $data['adress1']:"";
        $adres = isset($data['adress2'])? $data['adress2']:"";
        $post = isset($data['postcode'])? $data['postcode']:"";
        $city = isset($data['city'])? $data['city']:"";
        $state = isset($data['state'])? $data['state']:"";
        $phone = isset($data['phone'])? $data['phone']:(isset($_SESSION['user'])? $_SESSION['user']['phone']:"");
        $emal =isset($data['email'])? $data['email']:(isset($_SESSION['user'])? $_SESSION['user']['email']:"");
       
        if($cart['items'] !="[]"){
        
    ?>
    <div class="row" style="margin-top:50px">
       <div class="col-8">
        <div class="form">
        <h3>Your details</h3>

       
        <form method="post" id='shipping' onsubmit="return false">
        <label for="" style="padding: 5px 0;">Country</label>
        <select name="country" id="" class="form-control" required>
        <option value="<?=$country?>"><?=$country?></option>
        <option value="India">India</option>
        <option value="Pakstan">Pakstan</option>
        <option value="China">China</option>
        
        </select>
             <label for="" style="padding: 5px 0;">Full name</label>
            <input type="text" name="fname" value="<?=$name?>" class="form-control" required>
            <label for="" style="padding: 5px 0;">Adress line 1</label>
            <input type="text" name="adress1" value="<?=$address?>" class="form-control" required>
            <label for="" style="padding: 5px 0;">Adress line 2</label>
            <input type="text" name="adress2" value="<?=$adres?>" class="form-control" >
            <label for="" style="padding: 5px 0;">Postcode</label>
            <input type="text" name="post" value="<?=$post?>" class="form-control" required>
            <label for="" style="padding: 5px 0;">Town/City</label>
            <input type="text" name="city" value="<?=$city?>" class="form-control" required>
            <label for="" style="padding: 5px 0;">Provence/County/State</label>
            <input type="text" name="state" value="<?=$state?>" class="form-control" required>
            <label for="" style="padding: 5px 0;">Phone</label>
            <input type="phone" name="phone" value="<?=$phone?>" class="form-control" required>
            <label for="" style="padding: 5px 0;">Email</label>
            <input type="email" value="<?=$emal?>" name="email" class="form-control" required >
            <button class="btn" id="save" type="submit">Save & Continue</button>
        </form>
        </div>
       </div>
         <div class="col-4">
    
         </div>
    </div>
    <?php
        if($ct==1){
    ?>
    <div class="row" style="margin-top:50px">
       <div class="col-8">
        <div class="form">
     
        <h3>Confirm payment</h3>
      
           <div class="py">
        
           </div> 
      
        
        <hr>

        </div>
       </div>
         <div class="col-4">
        
         </div>
    </div>
    <?php }}} ?>
  </div>
  
  <!-- --------------------- footer area  -->
  <footer id="footer-area mt-3">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="pay-card text-center">
                    <i class="fa fa-paypal" aria-hidden="true"></i>
                    <i class="fa fa-cc-amex" aria-hidden="true"></i>
                    <i class="fa fa-cc-visa" aria-hidden="true"></i>
                    <i class="fa fa-cc-mastercard" aria-hidden="true"></i>
                    <i class="fa fa-credit-card-alt" aria-hidden="true"></i>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-12">
                <div class="copyright-text text-center">
                    <p>Copyright &copy; 2021 - Mengo .All Rights Reserved </p>
                </div>
            </div>
        </div>
    </div>
  </footer>

         <!-- all javascript link  -->
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery-1.12.4.min.js"></script>
    <script src="js/slick.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/custom.js"></script>
    <script src="js/checkout.js"></script>
    <script src="js/nav.js"></script>

    <script async src="https://pay.google.com/gp/p/js/pay.js"
    onload="onGooglePayLoaded()"></script>
    <script src="js/pay.js"></script>
 
</body>
</html>