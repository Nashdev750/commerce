<?php
spl_autoload_register(function($class){
    include "core/".$class.".php";
});
$db = new db;
if(!isset($_COOKIE['cart'])){
   
}else{
     $id= $_COOKIE['cart'];
    $cart = $db->readdb("SELECT * FROM `cart` WHERE `cartid`='".$id."'");
    echo $id;
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Products List </title>
    <link rel="stylesheet" href="css/font-awesome.min.css">
    <link rel="stylesheet" href="css/slick.css">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/media.css">
    <style>
        .nv button{
            width: 85px !important;
            margin: 0 !important;
            margin-bottom: -40px !important;
            display: flex;
            justify-content: center;
            align-items: center;
            padding-bottom: 0 !important;
          
        }
        .nv button div{
        
            
            display: flex;
            justify-content: baseline;
            align-items: baseline;
            padding: 0 !important;
        }
        .nv button div img{
        
  
       
    }
        .bb{
            border-bottom: 2px solid black !important;
        }
        .nn button{
            padding: 0 auto !important;
        }
       .nn::-webkit-scrollbar{
           display: none;
       }
    </style>
</head>

<body>

    <!-- ------ haeder area or navber area ------  -->
    <!-- <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <div class="container-fluid">
            <div class="collapse navbar-collapse" id="navbarSupportedContent">

            </div>
           
            <form class="d-flex">
                <input class="form-control" type="search" placeholder="Search" aria-label="Search">
            </form>
            <div class="nav-icons text-end d-flex">
                <i class="gg-search"></i>
                <i class="gg-profile"></i>
                <i class="gg-heart"></i>
                <i class="gg-shopping-bag"></i>
                <i>
                   
                </i>

            </div>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
          </button>
            </button>
           
            <aside class="sidebar">
                <div class="toggle">
                    <a href="#" class="burger js-menu-toggle" data-toggle="collapse" data-target="#main-navbar">
                        <span></span>
                    </a>
                </div>
                <div class="side-inner">

                    <div class="navbar-logoName">
                        <a href="#">MANGO</a>
                        <h3>Lorem ipsum <b>dolor sit.</b></h3>

                    </div>
                    <div class="manu-items">
                        <a href="#">
                            <div class="category-img d-flex">
                                <p>Category Name 1</p>
                                <img src="images/categori-man.png" alt="man">
                            </div>
                        </a>
                    </div>
                    <div class="manu-items">
                        <a href="#">
                            <div class="category-img d-flex">
                                <p>Category Name 2</p>
                                <img src="images/categori-man.png" alt="man">
                            </div>
                        </a>
                    </div>
                    <div class="manu-items">
                        <a href="#">
                            <div class="category-img d-flex">
                                <p>Category Name 3</p>
                                <img src="images/categori-man.png" alt="man">
                            </div>
                        </a>
                    </div>
                    <div class="manu-items">
                        <a href="#">
                            <div class="category-img d-flex">
                                <p>Category Name 4</p>
                                <img src="images/categori-man.png" alt="man">
                            </div>
                        </a>
                    </div>
                    <div class="manu-items">
                        <a href="#">
                            <div class="category-img d-flex">
                                <p>Category Name 5</p>
                                <img src="images/categori-man.png" alt="man">
                            </div>
                        </a>
                    </div>
                    <div class="manu-items">
                        <a href="#">
                            <div class="category-img d-flex">
                                <p>Category Name 6</p>
                                <img src="images/categori-man.png" alt="man">
                            </div>
                        </a>
                    </div>
                    <div class="manu-items">
                        <a href="#">
                            <div class="category-img d-flex">
                                <p>Category Name 7</p>
                                <img src="images/categori-man.png" alt="man">
                            </div>
                        </a>
                    </div>
                    <div class="manu-items">
                        <a href="#">
                            <div class="category-img d-flex">
                                <p>Category Name 8</p>
                                <img src="images/categori-man.png" alt="man">
                            </div>
                        </a>
                    </div>
                    <div class="manu-items">
                        <a href="#">
                            <div class="category-img d-flex">
                                <p>Category Name 9</p>
                                <img src="images/categori-man.png" alt="man">
                            </div>
                        </a>
                    </div>

                    <p class="nav-text">
                        Lorem ipsum dolor sit amet consectetur adipisicing elit. Necessitatibus, cumque!
                    </p>
                </div>

            </aside>
        </div>
    </nav> -->
    <!-- navbar all html end  -->
    <?php include 'partials/navbar.php';?>
    <!-- ------- filter area --------  -->
    <section id="filter-area">
        <div class="container text-center">
            <div class="row text-center">
                <div class="col-lg-12">
                <nav class="filter-line">
                        
                        <!-- -------- first filter -------------  -->
                        <div class="nav nav-tabs nav-one nv" id="nav-tab" role="tablist" style="min-width: 702px;border: none !important; width: 75%; ">
                            <button class="nav-link active" id="nav-f1-tab">
                                  <div class="color-img" id="color">
                                   
                                  </div>
                            </button>
                            <button class="nav-link" id="nav-f2-tab" >
                            <div class="color-img" id="length">
                                    
                                  </div>
                            </button>
                            <button class="nav-link" id="nav-f3-tab">
                            <div class="color-img" id="sleeve">
                                   
                                  </div>
                            </button>
                            <button class="nav-link" id="nav-f4-tab" style="width: 100px !important;">
                            <div class="color-img" id="neckline">
                                     
                                  </div>
                            </button>
                            <button class="nav-link" id="nav-f5-tab">
                            <div class="color-img" id="pattern">
                                   
                                  </div>
                            </button>
                            <button class="nav-link" id="nav-f6-tab">
                            <div class="color-img" id="cut">
                               
                                  </div>
                            </button>
                            <button class="nav-link" id="nav-f7-tab" style="width: 130px !important;">
                            <div class="color-img" id="sleevestyle">
                                     
                                  </div>
                            </button>
                        </div>
                    </nav>
                    <nav class="filter-line">
                       


                        
                        <!-- -------- first filter -------------  -->
                        <div class="nav nav-tabs nav-one nv nn" id="nav-tab" role="tablist" style="padding: 0 auto !important;">
                            <button class="nav-link active bb" id="nav-f1-tab" data-bs-toggle="tab" data-bs-target="#nav-f111" type="button" role="tab" aria-controls="nav-f1" aria-selected="true">Color</button>
                            <button class="nav-link" id="nav-f2-tab" data-bs-toggle="tab" data-bs-target="#nav-f2" type="button" role="tab" aria-controls="nav-f2" aria-selected="false">Length</button>
                            <button class="nav-link" id="nav-f3-tab" data-bs-toggle="tab" data-bs-target="#nav-f3" type="button" role="tab" aria-controls="nav-f3" aria-selected="false">Sleeve</button>
                            <button style="width: 100px !important;" class="nav-link" id="nav-f4-tab" data-bs-toggle="tab" data-bs-target="#nav-f4" type="button" role="tab" aria-controls="nav-f4" aria-selected="false">Neckline</button>
                            <button class="nav-link" id="nav-f5-tab" data-bs-toggle="tab" data-bs-target="#nav-f5" type="button" role="tab" aria-controls="nav-f5" aria-selected="false">Pattern</button>
                            <button class="nav-link" id="nav-f6-tab" data-bs-toggle="tab" data-bs-target="#nav-f6" type="button" role="tab" aria-controls="nav-f6" aria-selected="false">Cut</button>
                            <button style="width: 130px !important;" class="nav-link" id="nav-f7-tab" data-bs-toggle="tab" data-bs-target="#nav-f7" type="button" role="tab" aria-controls="nav-f7" aria-selected="false">Sleeve-Style</button>
                        </div>
                    </nav>
                    <div class="tab-content nav-two" id="nav-tabContent">
                        <!-- ---------------------- color filter-------------  -->
                        <div class="tab-pane fade show active" id="nav-f111" role="tabpanel" aria-labelledby="nav-f1-tab">
                            <nav>
                                <div class="container text-center">
                                    <div class="row text-center">
                                        <div class="col-lg-12 d-flex filterColor-center" id="fcolor">

                                            <div class="color-img">
                                                <img src="filter/color/Black@1x.png" height="40px" alt="dress">
                                            </div>

                                            <div class="color-img">
                                                <img src="filter/color/Brown@1x.png" height="40px" alt="dress">
                                            </div>

                                            <div class="color-img">
                                                <img src="filter/color/Denim_Blue@1x.png" height="40px" alt="dress">
                                            </div>

                                            <div class="color-img">
                                                <img src="filter/color/Green@1x.png" height="40px" alt="dress">
                                            </div>

                                            <div class="color-img">
                                                <img src="filter/color/Grey@1x.png" height="40px" alt="dress">
                                            </div>

                                            <div class="color-img">
                                                <img src="filter/color/Navy@1x.png" height="40px" alt="dress">
                                            </div>

                                            <div class="color-img">
                                                <img src="filter/color/Orange@1x.png" height="40px" alt="dress">
                                            </div>

                                            <div class="color-img">
                                                <img src="filter/color/Pink@1x.png" height="40px" alt="dress">
                                            </div>

                                            <div class="color-img">
                                                <img src="filter/color/Purple@1x.png" height="40px" alt="dress">
                                            </div>

                                            <div class="color-img">
                                                <img src="filter/color/Red@1x.png" height="40px" alt="dress">
                                            </div>

                                            <div class="color-img">
                                                <img src="filter/color/White@1x.png" height="40px" alt="dress">
                                            </div>

                                            <div class="color-img">
                                                <img src="filter/color/Yellow@1x.png" height="40px" alt="dress">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </nav>
                        </div>
                        <!-- ------------------------- Length filter ------------------------  -->
                        <div class="tab-pane fade" id="nav-f2" role="tabpanel" aria-labelledby="nav-f2-tab">
                            <nav>
                                <div class="container text-center">
                                    <div class="row text-center">
                                        <div class="col-lg-12 d-flex filterColor-center-l" id="flength">
                                            <div class="color-img">
                                                <img src="filter/Length/Asymmetric@1x.png" alt="a">
                                            </div>

                                            <div class="color-img">
                                                <img src="filter/Length/High_Low@1x.png" alt="a">
                                            </div>

                                            <div class="color-img">
                                                <img src="filter/Length/Maxi@1x.png" alt="a">
                                            </div>

                                            <div class="color-img">
                                                <img src="filter/Length/Midi@1x.png" alt="a">
                                            </div>

                                            <div class="color-img">
                                                <img src="filter/Length/Short@1x.png" alt="a">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </nav>
                        </div>
                        <!-- ---------------------------- Sleeve filter -------------------------  -->
                        <div class="tab-pane fade" id="nav-f3" role="tabpanel" aria-labelledby="nav-f3-tab">
                            <nav>
                                <div class="container text-center">
                                    <div class="row text-center">
                                        <div class="col-lg-12 d-flex filterColor-center-s" id="fsleeve">
                                            <div class="lenght-img">
                                                <img src="filter/Sleeve/3_4@1x.png" alt="ss">
                                            </div>


                                            <div class="lenght-img">
                                                <img src="filter/Sleeve/Cap@1x.png" alt="ss">
                                            </div>


                                            <div class="lenght-img">
                                                <img src="filter/Sleeve/Long@1x.png" alt="ss">
                                            </div>


                                            <div class="lenght-img">
                                                <img src="filter/Sleeve/Short@1x.png" alt="ss">
                                            </div>


                                            <div class="lenght-img">
                                                <img src="filter/Sleeve/Sleeveless@1x.png" alt="ss">
                                            </div>


                                            <div class="lenght-img">
                                                <img src="filter/Sleeve/Spaghetti_Strap@1x.png" alt="ss">
                                            </div>


                                            <div class="lenght-img">
                                                <img src="filter/Sleeve/Strapless@1x.png" alt="ss">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </nav>
                        </div>
                        <!-- ---------------------------- Neckline filter -------------------------  -->
                        <div class="tab-pane fade" id="nav-f4" role="tabpanel" aria-labelledby="nav-f4-tab">
                            <nav>
                                <div class="container text-center">
                                    <div class="row text-center">
                                        <div class="col-lg-12 d-flex filterColor-center-n" id="fneckline">
                                            <div class="color-img">
                                                <img src="filter/Neckline/Asymmetric_Neck@1x.png" alt="a">
                                            </div>

                                            <div class="color-img">
                                                <img src="filter/Neckline/Bardot_Neck@1x.png" alt="a">
                                            </div>

                                            <div class="color-img">
                                                <img src="filter/Neckline/Collar@1x.png" alt="a">
                                            </div>

                                            <div class="color-img">
                                                <img src="filter/Neckline/Cowl_Neck@1x.png" alt="a">
                                            </div>

                                            <div class="color-img">
                                                <img src="filter/Neckline/Halter_Neck@1x.png" alt="a">
                                            </div>

                                            <div class="color-img">
                                                <img src="filter/Neckline/Jewel_Neck@1x.png" alt="a">
                                            </div>

                                            <div class="color-img">
                                                <img src="filter/Neckline/Plunging_Neck@1x.png" alt="a">
                                            </div>

                                            <div class="color-img">
                                                <img src="filter/Neckline/Round_Neck@1x.png" alt="a">
                                            </div>

                                            <div class="color-img">
                                                <img src="filter/Neckline/Split_Neck@1x.png" alt="a">
                                            </div>

                                            <div class="color-img">
                                                <img src="filter/Neckline/Square_Neck@1x.png" alt="a">
                                            </div>

                                            <div class="color-img">
                                                <img src="filter/Neckline/Surplice_Neck@1x.png" alt="a">
                                            </div>

                                            <div class="color-img">
                                                <img src="filter/Neckline/Sweetheart@1x.png" alt="a">
                                            </div>

                                            <div class="color-img">
                                                <img src="filter/Neckline/Turtleneck@1x.png" alt="a">
                                            </div>

                                            <div class="color-img">
                                                <img src="filter/Neckline/V_Neck@1x.png" alt="a">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </nav>
                        </div>
                        <!-- ---------------------------- Pattern filter -------------------------  -->
                        <div class="tab-pane fade" id="nav-f5" role="tabpanel" aria-labelledby="nav-f5-tab">
                            <nav>
                                <div class="container text-center">
                                    <div class="row text-center">
                                        <div class="col-lg-12 d-flex filterColor-center-p" id="fpattern">
                                            <div class="color-img">
                                                <img src="filter/pattern/Animal@1x.png" alt="a">
                                            </div>

                                            <div class="color-img">
                                                <img src="filter/pattern/Color_Block@1x.png" alt="a">
                                            </div>

                                            <div class="color-img">
                                                <img src="filter/pattern/Dot@1x.png" alt="a">
                                            </div>

                                            <div class="color-img">
                                                <img src="filter/pattern/Floral@1x.png" alt="a">
                                            </div>

                                            <div class="color-img">
                                                <img src="filter/pattern/Geometric@1x.png" alt="a">
                                            </div>

                                            <div class="color-img">
                                                <img src="filter/pattern/Lace@1x.png" alt="a">
                                            </div>

                                            <div class="color-img">
                                                <img src="filter/pattern/Other@1x.png" alt="a">
                                            </div>

                                            <div class="color-img">
                                                <img src="filter/pattern/Plaid@1x.png" alt="a">
                                            </div>

                                            <div class="color-img">
                                                <img src="filter/pattern/Solid@1x.png" alt="a">
                                            </div>

                                            <div class="color-img">
                                                <img src="filter/pattern/Stripe@1x.png" alt="a">
                                            </div>
                                        </div>
                                    </div>
                                </div>

                            </nav>
                        </div>
                        <!-- ---------------------------- cut filter -------------------------  -->
                        <div class="tab-pane fade" id="nav-f6" role="tabpanel" aria-labelledby="nav-f6-tab">
                            <nav>
                                <div class="container text-center">
                                    <div class="row text-center">
                                        <div class="col-lg-12 d-flex filterColor-center-c" id="fcut">
                                            <div class="color-img">
                                                <img src="filter/cut/Fitted@1x.png" alt="a">
                                            </div>

                                            <div class="color-img">
                                                <img src="filter/cut/Flared@1x.png" alt="a">
                                            </div>

                                            <div class="color-img">
                                                <img src="filter/cut/Mermaid@1x.png" alt="a">
                                            </div>

                                            <div class="color-img">
                                                <img src="filter/cut/Straight@1x.png" alt="a">
                                            </div>
                                        </div>
                                    </div>
                                </div>

                            </nav>
                        </div>
                        <!-- ----------------------------Sleeve-Style  filter -------------------------  -->
                        <div class="tab-pane fade" id="nav-f7" role="tabpanel" aria-labelledby="nav-f7-tab">
                            <nav>
                                <div class="container text-center">
                                    <div class="row text-center">
                                        <div class="col-lg-12 d-flex filterColor-center-ss" id="fsleevestyle">
                                            <div class="color-img">
                                                <img src="filter/sleeve-style/Balloon_Sleeve@1x.png" alt="a">
                                            </div>

                                            <div class="color-img">
                                                <img src="filter/sleeve-style/Bell_Sleeve@1x.png" alt="a">
                                            </div>

                                            <div class="color-img">
                                                <img src="filter/sleeve-style/Cold_Shoulder@1x.png" alt="a">
                                            </div>

                                            <div class="color-img">
                                                <img src="filter/sleeve-style/Dolman_Sleeve@1x.png" alt="a">
                                            </div>

                                            <div class="color-img">
                                                <img src="filter/sleeve-style/Kimono_Sleeve@1x.png" alt="a">
                                            </div>

                                            <div class="color-img">
                                                <img src="filter/sleeve-style/Off_The_Shoulder@1x.png" alt="a">
                                            </div>

                                            <div class="color-img">
                                                <img src="filter/sleeve-style/One_Shoulder@1x.png" alt="a">
                                            </div>

                                            <div class="color-img">
                                                <img src="filter/sleeve-style/Raglan_Sleeve@1x.png" alt="a">
                                            </div>

                                            <div class="color-img">
                                                <img src="filter/sleeve-style/Ruffle_Sleeve@1x.png" alt="a">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- ------------------ product display  -->
    <section id="productList">
        <div class="product01">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12 d-flex row" id="row">
                        <!-- <div class="col-lg-3 p-img text-center">
                            <img src="images/product11 (3).jpg" alt="img">
                            <h3>product name</h3>
                            <div class="prize text-center">
                                $40.88
                            </div>
                            <div class="color-co text-center">
                                <img src="filter/color/Black@1x.png" height="30px" alt="">
                                <img src="filter/color/Denim_Blue@1x.png" height="30px" alt="">
                            </div>
                            <i class="fa fa-heart heart"></i>
                        </div> -->

                        
                    </div>
                </div>
            </div>
        </div>

        <!-- <div class="product-gap">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12 d-flex" id="row">
                        <div class="col-lg-3 p-img text-center">
                            <img src="images/product11 (3).jpg" alt="img">
                            <h3>product name</h3>
                            <div class="prize text-center">
                                $40.88
                            </div>
                            <div class="color-co text-center">
                                <img src="filter/color/Black@1x.png" height="30px" alt="">
                                <img src="filter/color/Denim_Blue@1x.png" height="30px" alt="">
                            </div>
                            <i class="fa fa-heart heart"></i>
                        </div>

                        <div class="col-lg-3 p-img text-center">
                            <img src="images/product11 (3).jpg" alt="img">
                            <h3>product name</h3>
                            <div class="prize text-center">
                                $40.88
                            </div>
                            <div class="color-co text-center">
                                <img src="filter/color/Black@1x.png" height="30px" alt="">
                                <img src="filter/color/Denim_Blue@1x.png" height="30px" alt="">
                            </div>
                            <i class="fa fa-heart heart"></i>
                        </div>

                        <div class="col-lg-3 p-img text-center none">
                            <img src="images/product11 (3).jpg" alt="img">
                            <h3>product name</h3>
                            <div class="prize text-center">
                                $40.88
                            </div>
                            <div class="color-co text-center ">
                                <img src="filter/color/Black@1x.png" height="30px" alt="">
                                <img src="filter/color/Denim_Blue@1x.png" height="30px" alt="">
                            </div>
                            <i class="fa fa-heart heart"></i>
                        </div>

                        <div class="col-lg-3 p-img text-center none">
                            <img src="images/product11 (3).jpg" alt="img">
                            <h3>product name</h3>
                            <div class="prize text-center">
                                $40.88
                            </div>
                            <div class="color-co text-center">
                                <img src="filter/color/Black@1x.png" height="30px" alt="">
                                <img src="filter/color/Denim_Blue@1x.png" height="30px" alt="">
                            </div>
                            <i class="fa fa-heart heart"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div> -->
    </section>
    <!-- ---------------------------- social area  -->
    <section id="social-area">
        <div class="container">
            <div class="row text-center">
                <div class="col-12">
                    <div class="social-icon">
                        <a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a>
                        <a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a>
                        <a href="#"><i class="fa fa-github" aria-hidden="true"></i></a>
                        <a href="#"><i class="fa fa-instagram" aria-hidden="true"></i></a>
                        <a href="#"><i class="fa fa-youtube-play" aria-hidden="true"></i></a>
                    </div>
                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Hic officiis harum aut in autem tempora?</p>
                </div>
            </div>
            <div class="row">
                <div class="col-12">
                    <div class="signup-btn">
                        <form action="#">
                            <input type="text">
                            <input class="sub-btn" type="submit" value="Sign Up">
                        </form>
                    </div>
                </div>
                <div class="end-link">
                    <p class="mt-5"> <a href="#">Products</a> </p>
                    <hr>
                    <a href="#">About Us</a>
                    <hr>
                    <a href="#">Useful Information</a>
                    <hr>
                </div>
            </div>
        </div>
    </section>
    <!-- --------------------- footer area  -->
    <footer id="footer-area">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="pay-card text-center">
                        <i class="fa fa-paypal" aria-hidden="true"></i>
                        <i class="fa fa-cc-amex" aria-hidden="true"></i>
                        <i class="fa fa-cc-visa" aria-hidden="true"></i>
                        <i class="fa fa-cc-mastercard" aria-hidden="true"></i>
                        <i class="fa fa-credit-card-alt" aria-hidden="true"></i>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12">
                    <div class="copyright-text text-center">
                        <p>Copyright &copy; 2021 - Mengo .All Rights Reserved </p>
                    </div>
                </div>
            </div>
        </div>
    </footer>



    <!-- all javascript link  -->
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery-1.12.4.min.js"></script>
    <script src="js/slick.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/custom.js"></script>
    <script src="js/load.js"></script>
    <script src="js/nav.js"></script>
</body>

</html>