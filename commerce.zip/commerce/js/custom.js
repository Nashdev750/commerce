$(function() {



    //toggle two classes on button element
    $('heart').on('click', function() {
        $('heart').toggleClass('.heart_active');
    });
    // slick slider for blog section 
    $('.cus-card-main').slick({
        slidesToShow: 5,
        slidesToScroll: 1,
        autoplay: true,
        autoplaySpeed: 2000,
        prevArrow: $('.re-left'),
        nextArrow: $('.re-right'),
        responsive: [{
            breakpoint: 400,
            settings: {
                slidesToShow: 2,
                slidesToScroll: 1,
            }
        }]
    });

    // banner slider for blog section 
    $('.banner-slider-main').slick({
        slidesToShow: 1,
        slidesToScroll: 1,
        autoplay: true,
        autoplaySpeed: 2000,
        prevArrow: $('.left'),
        nextArrow: $('.right')
    });
    // cart product slider for  section 
    $('.cart-product-img').slick({
        slidesToShow: 1,
        slidesToScroll: 1,
        autoplay: false,
        arrows: false,
        autoplaySpeed: 2000,
        dots: true,
        fade: true,
    });

    // --------- cart page silder ------- 
    $('.cart-view').slick({
        slidesToShow: 1,
        slidesToScroll: 1,
        autoplay: true,
        autoplaySpeed: 2000,
        arrows: false,
    });


    //    ------------------ filter JS ------------ 
    var $filter = $('.filter');
    var $tab = $('.filter a');
    var $offers = $('.boxGroup .box')



    $filter.on('click touch', '.all', function(e) {
        e.preventDefault();
        $tab.removeClass('current');
        $(this).addClass('current');

        $offers.hide();
        $offers.fadeIn(700);

    });


    $filter.on('click touch', '.one', function(e) {
        e.preventDefault();
        $tab.removeClass('current');
        $(this).addClass('current');

        $offers.show();
        $offers.fadeOut(400);
        $offers.filter('.one').fadeIn(400);

    });



    $filter.on('click touch', '.two', function(e) {
        e.preventDefault();
        $tab.removeClass('current');
        $(this).addClass('current');

        $offers.show();
        $offers.fadeOut(400);
        $offers.filter('.two').fadeIn(400);

    });



    $filter.on('click touch', '.three', function(e) {
        e.preventDefault();
        $tab.removeClass('current');
        $(this).addClass('current');

        $offers.show();
        $offers.fadeOut(400);
        $offers.filter('.three').fadeIn(400);

    });


});

// side bar js here 
$(document).ready(function() {
    var trigger = $('.hamburger'),
        overlay = $('.overlay'),
        isClosed = false;

    trigger.click(function() {
        hamburger_cross();
    });

    function hamburger_cross() {

        if (isClosed == true) {
            overlay.hide();
            trigger.removeClass('is-open');
            trigger.addClass('is-closed');
            isClosed = false;
        } else {
            overlay.show();
            trigger.removeClass('is-closed');
            trigger.addClass('is-open');
            isClosed = true;
        }
    }

    $('[data-toggle="offcanvas"]').click(function() {
        $('#wrapper').toggleClass('toggled');
    });
});

//   side nav 
$(function() {

    'use strict';

    $('.js-menu-toggle').click(function(e) {

        var $this = $(this);



        if ($('body').hasClass('show-sidebar')) {
            $('body').removeClass('show-sidebar');
            $this.removeClass('active');
        } else {
            $('body').addClass('show-sidebar');
            $this.addClass('active');
        }

        e.preventDefault();

    });

    // click outisde offcanvas
    $(document).mouseup(function(e) {
        var container = $(".sidebar");
        if (!container.is(e.target) && container.has(e.target).length === 0) {
            if ($('body').hasClass('show-sidebar')) {
                $('body').removeClass('show-sidebar');
                $('body').find('.js-menu-toggle').removeClass('active');
            }
        }
    });



});