const cl = document.querySelector('.log')
const side = document.querySelector('.side')
const over = document.querySelector('.over')
const sat = document.querySelector('.sert')
const no = document.querySelector('.no')
const cls = document.querySelector('.cls')

cl.addEventListener('click', () => {
    over.classList.add('sh')
    side.classList.add('m')
})

over.addEventListener('click', clear);

function clear() {
    side.classList.remove('m')
    this.classList.remove('sh')

}

no.addEventListener('click', () => {

    sat.classList.add('se')
})
cls.addEventListener('click', () => {
    sat.classList.remove('se')
})