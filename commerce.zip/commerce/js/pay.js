const frm = document.querySelector('#shipping')
const bt = document.querySelector('#save')





const py = document.querySelector('.py')
let googlePayClient;
const tokenizationSpecification = {
    type: 'PAYMENT_GATEWAY',
    parameters: {
        gateway: 'example',
        gatewayMerchantId: 'gatewayMerchantId',
    }

}
let supportedInstruments = {
    type: 'CARD',
    tokenizationSpecification: tokenizationSpecification,
    parameters: {
        allowedCardNetworks: ['VISA', 'MASTERCARD'],
        allowedAuthMethods: ['PAN_ONLY', 'CRYPTOGRAM_3DS'],
    }
}


const config = {
    apiVersion: 2,
    apiVersionMinor: 0,
    allowedPaymentMethods: [supportedInstruments]
}

function onGooglePayLoaded() {
    googlePayClient = new google.payments.api.PaymentsClient({
        environment: "TEST"
    });
    googlePayClient.isReadyToPay(config)
        .then(res => {
            if (res.result) {
                addbtn();
            } else {
                console.log(res)
            }
        })
        .catch(err => console.log(err))
}

function addbtn() {

    const button = googlePayClient.createButton({
        buttonColor: 'default',
        buttonType: 'buy',
        onClick: ongooglepayclicked,
    });
    py.appendChild(button)

}


function ongooglepayclicked() {

    const paymentDataRequest = {...config };
    paymentDataRequest.merchantInfo = {
        merchantId: '6580danish-1@okaxis',
        merchantName: 'rebelane',
    };
    paymentDataRequest.transactionInfo = {
        totalPriceStatus: 'FINAL',
        totalPrice: '500',
        currencyCode: 'INR',
        countryCode: '91',
    };
    googlePayClient.loadPaymentData(paymentDataRequest)
        .then(paymentData => processPaymentData(paymentData))
        .catch(err => console.log(err))
}

function processPaymentData(data) {

    fetch(`core/pay.php`, {
        method: 'POST',
        headers: { 'Content-type': 'application/json' },
        body: data
    })
}

bt.addEventListener('click', () => {

    fetch('core/shipping.php', {
            method: 'post',
            body: new FormData(frm)
        })
        .then(res => res.text())
        .then(data => {
            console.log(data)
            if (data == 'save') {
                location.reload()
            } else {
                console.log(data)


            }
        })
})