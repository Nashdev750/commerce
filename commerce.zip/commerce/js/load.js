const row = document.querySelector('#row');
const colors = document.querySelectorAll('#fcolor img');
const lens = document.querySelectorAll('#flength img');
const sleeves = document.querySelectorAll('#fsleeve img');
const necks = document.querySelectorAll('#fneckline img');
const patterns = document.querySelectorAll('#fpattern img');
const cuts = document.querySelectorAll('#fcut img');
const styles = document.querySelectorAll('#fsleevestyle img');
const btns = document.querySelectorAll('.nn button');



let query = "SELECT * FROM products"
load(query);
filterlist = {
    "color": "",
    "length": "",
    "sleeve": "",
    "neckline": "",
    "pattern": "",
    "cut": "",
    "sleevestyle": "",
};

function load(query) {
    fetch(`core/load.php?q=${query}`)
        .then(res => res.json())
        .then(data => {
            console.log(data)
            let p = ''
            data.forEach(product => {
                p += `
              <div class="col-lg-3 p-img text-center">
              <a href="cartpage?id=${product.id}"><img id="thub" src="images/${product.image}" alt="img"></a> 
                            <h3>  ${product.pname}</h3>
                            <div class="prize text-center">
                                $${product.price}
                            </div>
                            <div class="color-co text-center">
                                <img src="filter/color/Black@1x.png" height="30px" alt="">
                                <img src="filter/color/Denim_Blue@1x.png" height="30px" alt="">
                            </div>
                          
                        </div>
              `
            });

            row.innerHTML = p






        })
}

colors.forEach(color => color.addEventListener('click', fcolor))

function fcolor() {

    let el = this.getAttribute('src').split("/")
    let el2 = el[2].split(".")
    filterlist.color = el2[0]
    generatefilter(filterlist);



    document.querySelector('#color').innerHTML = `<img src="${this.getAttribute('src')}" height="40px" alt="dress">`

}
document.querySelector('#color').addEventListener('click', clear);

function clear() {
    this.innerHTML = ""
    filterlist.color = ""
    generatefilter(filterlist)
}

// lengths
lens.forEach(len => len.addEventListener('click', lenth))

function lenth() {

    let el = this.getAttribute('src').split("/")
    let el2 = el[2].split(".")
    filterlist.length = el2[0]
    generatefilter(filterlist);
    document.querySelector('#length').innerHTML = `<img src="${this.getAttribute('src')}" height="40px" alt="dress">`

}
document.querySelector('#length').addEventListener('click', lenclear);

function lenclear() {
    this.innerHTML = ""
    filterlist.length = ""
    generatefilter(filterlist)
}

//sleeve
sleeves.forEach(sleeve => sleeve.addEventListener('click', fsleeve))

function fsleeve() {

    let el = this.getAttribute('src').split("/")
    let el2 = el[2].split(".")
    filterlist.sleeve = el2[0]
    generatefilter(filterlist);
    document.querySelector('#sleeve').innerHTML = `<img src="${this.getAttribute('src')}" height="40px" alt="dress">`

}
document.querySelector('#sleeve').addEventListener('click', slclear);

function slclear() {
    this.innerHTML = ""
    filterlist.sleeve = ""
    generatefilter(filterlist)
}

// neckline
necks.forEach(neck => neck.addEventListener('click', neckl))

function neckl() {

    let el = this.getAttribute('src').split("/")
    let el2 = el[2].split(".")
    filterlist.neckline = el2[0]
    generatefilter(filterlist);
    document.querySelector('#neckline').innerHTML = `<img src="${this.getAttribute('src')}" height="40px" alt="dress">`

}
document.querySelector('#neckline').addEventListener('click', nclear);

function nclear() {
    this.innerHTML = ""
    filterlist.neckline = ""
    generatefilter(filterlist)
}
// pattern
patterns.forEach(pat => pat.addEventListener('click', patt))

function patt() {


    let el = this.getAttribute('src').split("/")
    let el2 = el[2].split(".")
    filterlist.pattern = el2[0]
    generatefilter(filterlist);
    document.querySelector('#pattern').innerHTML = `<img src="${this.getAttribute('src')}" height="40px" alt="dress">`

}
document.querySelector('#pattern').addEventListener('click', pclear);

function pclear() {
    this.innerHTML = ""
    filterlist.pattern = ""
    generatefilter(filterlist)
}

// cut
cuts.forEach(cut => cut.addEventListener('click', fcut))

function fcut() {

    let el = this.getAttribute('src').split("/")
    let el2 = el[2].split(".")
    filterlist.cut = el2[0]
    generatefilter(filterlist);
    document.querySelector('#cut').innerHTML = `<img src="${this.getAttribute('src')}" height="40px" alt="dress">`

}
document.querySelector('#cut').addEventListener('click', cclear);

function cclear() {
    this.innerHTML = ""
    filterlist.cut = ""
    generatefilter(filterlist)
}

// sleevestyle
styles.forEach(sty => sty.addEventListener('click', fst))

function fst() {

    let el = this.getAttribute('src').split("/")
    let el2 = el[2].split(".")
    filterlist.sleevestyle = el2[0]
    generatefilter(filterlist);
    document.querySelector('#sleevestyle').innerHTML = `<img src="${this.getAttribute('src')}" height="40px" alt="dress">`

}
document.querySelector('#sleevestyle').addEventListener('click', stclear);

function stclear() {
    this.innerHTML = ""
    filterlist.sleevestyle = ""
    generatefilter(filterlist)
}

function generatefilter(filterlist) {
    query = 'SELECT * FROM products WHERE status =0'
    if (filterlist.color != "") {
        if (query.search('color') == -1) {
            query += ` AND color='${filterlist.color}'`;
        }
    }
    if (filterlist.sleeve != "") {
        if (query.search('sleeve') == -1) {
            query += ` AND sleeve='${filterlist.sleeve}'`;
        }

    }
    if (filterlist.length != "") {
        if (query.search('length') == -1) {
            query += ` AND length='${filterlist.length}'`;
        }
    }
    if (filterlist.pattern != "") {
        if (query.search('pattern') == -1) {
            query += ` AND pattern='${filterlist.pattern}'`;
        }
    }
    if (filterlist.cut != "") {
        if (query.search('cut') == -1) {
            query += ` AND cut='${filterlist.cut}'`;
        }
    }
    if (filterlist.sleevestyle != "") {
        if (query.search('sleevestyle') == -1) {
            query += ` AND sleeve_style='${filterlist.sleevestyle}'`;
        }
    }
    if (filterlist.neckline != "") {
        if (query.search('neckline') == -1) {
            query += ` AND neckline='${filterlist.neckline}'`;
        }
    }

    console.log(query)
    load(query)

}
btns.forEach(btn => btn.addEventListener('click', addborder))


function addborder() {
    btns.forEach(btn => btn.classList.remove('bb'))
    this.classList.add('bb')
}