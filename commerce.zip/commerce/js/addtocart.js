const add = document.querySelector('#addtocart')
const color = document.querySelectorAll('#colors')
const size = document.querySelector('.Quselect')
const bag = document.querySelector('.bagitem')

add.addEventListener('click', addtocart)
let col = ""


function addtocart() {
    if (size.value == "") {
        alert("choose size")
    } else if (col == "") {
        alert("choose color")
    } else {
        let z = size.value;
        data = `${this.dataset.cart}-${col}-${z}`;
        fetch(`core/addtocart.php?id=${data}`)
            .then(res => res.text())
            .then(data => {
                if (data == "added") {

                    let n = Number(bag.innerText) + 1;
                    bag.innerText = n;


                } else {

                }
            })
    }

}

color.forEach(col => col.addEventListener('click', selcol))

function selcol() {
    color.forEach(col => col.classList.remove('b'))
    this.classList.add('b')
    col = this.dataset.color
}