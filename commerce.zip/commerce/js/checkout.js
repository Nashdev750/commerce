const body = document.querySelector('.tbody')

load();



function load() {
    fetch(`core/checkout.php`)
        .then(res => res.json())
        .then(data => {
            console.log(data)
            s = '';
            count = 0;
            price = 0;
            data.forEach(item => {

                price += Math.round(Number(item.price * item.qty), 2);
                s += `
                  <tr>
                  <td>
                    <div class="item">
   
                    <img src="images/${item.image}" alt="cart img">
                    <div>
                    <p>${item.name}</p>
                    <img class=""  id="colors" data-color="Denim_Blue@1x" src="filter/color/${item.color}.png" height="30px" alt="color">
                    </div>
                    </div>
   
                  </td> <td>
                  <select name="size" id="" class="Quselect" style="min-width:50px">
                  <option value="${item.size}">${item.size}</option>
                  <option value="xxs">XXS</option>
                  <option value="xs">XS</option>
                  <option value="s">S</option>
                  <option value="m">M</option>
                  <option value="l">L</option>
                 </select>
                  </td> <td>
                  
                  <select name="quantity" id="rr" onchange="return qty(${count},${item.id},'${item.color}','${item.size}')"  class="Quselect" style="min-width:50px">
                  <option value="${item.qty}">${item.qty}</option>
                  <option value="1">1</option>
                  <option value="2">2</option>
                  <option value="3">3</option>
                  <option value="4">4</option>
                  <option value="5">5</option>
                 </select>
                  </td>
                  <td>$${Number(item.price*item.qty)}</td> <td> <a  onclick="return remove(${item.id},'${item.color}','${item.size}')" style="cursor:pointer">Remove</a></td>
               </tr>
                  `;
                count++;
            });

            body.innerHTML = s;
            document.querySelector('#tp').innerHTML = `USD ${price}`
            document.querySelector('#np').innerHTML = `${count} Products`
            document.querySelector('.bagitem').innerText = count
            document.querySelector('#st').innerHTML = `USD ${price}`
        })

}

function remove(id, color, size) {
    price = 0
    fetch(`core/remove.php?id=${id}&color=${color}&size=${size}`)
        .then(res => res.text())
        .then(data => {
            console.log(data)
            if (data) {
                load()
            }
        });
}

function qty(idx, id, color, size) {
    let val = document.querySelectorAll('#rr')[idx].value

    price = 0
    fetch(`core/qty.php?id=${id}&color=${color}&size=${size}&qty=${val}`)
        .then(res => res.text())
        .then(data => {
            console.log(data)
            if (data) {
                load()
            }
        });
}