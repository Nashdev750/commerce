let frm = document.querySelector('#frm')
let b = document.querySelector('.b')
let ln = document.querySelector('.ln')
let lg = document.querySelector('#lg')


b.addEventListener('click', () => {
    fetch(`core/register.php`, {
            method: "post",
            body: new FormData(frm)
        })
        .then(res => res.text())
        .then(data => {
            alert(data)
        })
})


ln.addEventListener('click', () => {
    fetch(`core/login.php`, {
            method: "post",
            body: new FormData(lg)
        })
        .then(res => res.text())
        .then(data => {
            if (data == 1) {
                alert("Email or password is incorrect")
            } else {
                location.reload();
            }
        })
})