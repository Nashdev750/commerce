const imgs = document.querySelectorAll('#qsect img');

imgs.forEach(img => img.addEventListener('click', addquiz));

function addquiz() {
    fetch(`core/quizb.php?a=${this.dataset.choice}`)
        .then(res => res.text())
        .then(data => {
            console.log(data)
            if (data == "next") {
                location.reload()
            } else {
                alert(data)
            }
        })
}