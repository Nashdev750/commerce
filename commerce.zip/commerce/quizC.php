<?php
 session_start();
 spl_autoload_register(function($class){
     include "core/".$class.".php";
 });
 
 $db = new db;


if(!isset($_SESSION['quiz'])){
    header("location:index");
   
}

if($_SESSION['quiz']['quiza']==""){
    header("location:quizA");
  
  }
  
if($_SESSION['quiz']['quizc']!=""){
  if($_SESSION['quiz']['quizc']=="C1"){
    header("location:productslist?cat=invertedtriangle");
}elseif($_SESSION['quiz']['quizc']=="C2"){
    header("location:productslist?cat=rectangle");
}elseif($_SESSION['quiz']['quizc']=="C3"){
    header("location:quizF");
}


}





?>


<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>quiz C </title>
    <link rel="stylesheet" href="css/font-awesome.min.css">
    <link rel="stylesheet" href="css/slick.css">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/media.css">
</head>
<body>
<?php include 'partials/navbar.php';?>
   
    <!-- ------ haeder area or navber area ------  -->
    <!-- <nav class="navbar navbar-expand-lg navbar-light bg-light">
      <div class="container-fluid">
          <div class="collapse navbar-collapse" id="navbarSupportedContent">
             
            </div>
        <a class="navbar-brand text-start" href="#">Navbar</a>
        <form class="d-flex">
          <input class="form-control" type="search" placeholder="Search" aria-label="Search">
        </form>
        <div class="nav-icons text-end d-flex">
          <i class="gg-search"></i>
          <i class="gg-profile"></i>
          <i class="gg-heart"></i>
          <i class="gg-shopping-bag"></i>
         
        </div>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
          </button>
        </button> -->
        <!-- ------ side navbar  -->
        <!-- <aside class="sidebar">
          <div class="toggle">
              <a href="#" class="burger js-menu-toggle" data-toggle="collapse" data-target="#main-navbar">
                 <span></span>
                  </a>
            </div>
          <div class="side-inner">
    
            <div class="navbar-logoName">
              <a href="#">MANGO</a>
              <h3>Lorem ipsum <b>dolor sit.</b></h3>
    
            </div>
            <div class="manu-items">
              <a href="#">
                  <div class="category-img d-flex">
                      <p>Category Name 1</p>
                      <img src="images/categori-man.png" alt="man">
                  </div>
              </a>
            </div>
            <div class="manu-items">
              <a href="#">
                  <div class="category-img d-flex">
                      <p>Category Name 2</p>
                      <img src="images/categori-man.png" alt="man">
                  </div>
              </a>
            </div>
            <div class="manu-items">
              <a href="#">
                  <div class="category-img d-flex">
                      <p>Category Name 3</p>
                      <img src="images/categori-man.png" alt="man">
                  </div>
              </a>
            </div>
            <div class="manu-items">
              <a href="#">
                  <div class="category-img d-flex">
                      <p>Category Name 4</p>
                      <img src="images/categori-man.png" alt="man">
                  </div>
              </a>
            </div>
            <div class="manu-items">
              <a href="#">
                  <div class="category-img d-flex">
                      <p>Category Name 5</p>
                      <img src="images/categori-man.png" alt="man">
                  </div>
              </a>
            </div>
            <div class="manu-items">
              <a href="#">
                  <div class="category-img d-flex">
                      <p>Category Name 6</p>
                      <img src="images/categori-man.png" alt="man">
                  </div>
              </a>
            </div>
            <div class="manu-items">
              <a href="#">
                  <div class="category-img d-flex">
                      <p>Category Name 7</p>
                      <img src="images/categori-man.png" alt="man">
                  </div>
              </a>
            </div>
            <div class="manu-items">
              <a href="#">
                  <div class="category-img d-flex">
                      <p>Category Name 8</p>
                      <img src="images/categori-man.png" alt="man">
                  </div>
              </a>
            </div>
            <div class="manu-items">
              <a href="#">
                  <div class="category-img d-flex">
                      <p>Category Name 9</p>
                      <img src="images/categori-man.png" alt="man">
                  </div>
              </a>
            </div>

            <p class="nav-text">
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Necessitatibus, cumque!
            </p>
          </div>
          
        </aside>
      </div>
    </nav> -->
    <!-- navbar all html end  -->
<section id="quizpage">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="quiz-content">
                    <h2>Understanding Your Body Type</h2>
                </div>
            </div>
        </div>
    </div>
</section>
<section id="ques1">
   <div class="container">
       <div class="row">
           <div class="col-12 text-center mt-5">
            <div class="progress">
                <div class="progress-bar" role="progressbar" style="width: 15%" aria-valuenow="15" aria-valuemin="0" aria-valuemax="100"></div>
                <div class="progress-bar bg-success" role="progressbar" style="width: 30%" aria-valuenow="30" aria-valuemin="0" aria-valuemax="100"></div>
                <div class="progress-bar bg-info" role="progressbar" style="width: 20%" aria-valuenow="20" aria-valuemin="0" aria-valuemax="100"></div>
              </div>
                   <p>
                       WHICH IS LARGER, YOUR BUST OR HIPS OR ARE THEY ABOUT THE SAME?
                   </p>
                <div class="row">
                    <div class="col-12">
                        
                <div class="q1-img d-flex" id="qsect">
                    <img data-choice="C1" src="quiz/C1.png" style="width: 100px;" alt="">
                    <img data-choice="C2" src="quiz/C2.png" style="width: 100px;"  alt="">
                    <img data-choice="C3" src="quiz/C3.png" style="width: 100px;" alt="">
                </div>
                    </div>
                </div>
           </div>
       </div>
   </div>
</section>

 <!-- ---------------------------- social area  -->
 <section id="social-area">
    <div class="container">
        <div class="row text-center">
            <div class="col-12">
                <div class="social-icon">
                  <a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a>
                  <a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a>
                  <a href="#"><i class="fa fa-github" aria-hidden="true"></i></a>
                  <a href="#"><i class="fa fa-instagram" aria-hidden="true"></i></a>
                  <a href="#"><i class="fa fa-youtube-play" aria-hidden="true"></i></a>
                </div>
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Hic officiis harum aut in autem tempora?</p>
            </div>
        </div>
        <div class="row">
            <div class="col-12">
              <div class="signup-btn">
                  <form action="#">
                      <input type="text">
                      <input class="sub-btn" type="submit" value="Sign Up">
                  </form>
              </div>
            </div>
            <div class="end-link">
                <p class="mt-5"> <a  href="#">Products</a> </p>
                <hr>
                <a href="#">About Us</a>
                <hr>
                <a href="#">Useful Information</a>
                <hr>
            </div>
        </div>
    </div>
</section>
<!-- --------------------- footer area  -->
<footer id="footer-area">
  <div class="container">
      <div class="row">
          <div class="col-12">
              <div class="pay-card text-center">
                  <i class="fa fa-paypal" aria-hidden="true"></i>
                  <i class="fa fa-cc-amex" aria-hidden="true"></i>
                  <i class="fa fa-cc-visa" aria-hidden="true"></i>
                  <i class="fa fa-cc-mastercard" aria-hidden="true"></i>
                  <i class="fa fa-credit-card-alt" aria-hidden="true"></i>
              </div>
          </div>
      </div>
      <div class="row">
          <div class="col-lg-12">
              <div class="copyright-text text-center">
                  <p>Copyright &copy; 2021 - Mengo .All Rights Reserved </p>
              </div>
          </div>
      </div>
  </div>
</footer>

        <!-- all javascript link  -->
        <script src="js/bootstrap.min.js"></script>
        <script src="js/jquery-1.12.4.min.js"></script>
        <script src="js/slick.min.js"></script>
        <script src="js/popper.min.js"></script>
        <script src="js/custom.js"></script>
        <script src="js/quizc.js"></script>
        <script src="js/nav.js"></script>
  </body>
  </html>