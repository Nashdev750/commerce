<?php
spl_autoload_register(function($class){
    include "core/".$class.".php";
});
$db = new db;

if(isset($_GET['id'])){
  $product = $db->readdbone("SELECT * FROM products WHERE id='".(int)trim($_GET['id'])."'");

}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <base href="/commerce/">
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cart Page </title>
    <link rel="stylesheet" href="css/font-awesome.min.css">
    <link rel="stylesheet" href="css/slick.css">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/media.css">
    <style>
     .b{
       border:1px solid Black;
     
       transition:.4s all
     }

    </style>
</head>
<body style="padding-top: 15px;">
   
<?php include 'partials/navbar.php';?>
    <!-- ------ haeder area or navber area ------  -->
    <!-- <nav class="navbar navbar-expand-lg navbar-light bg-light">
      <div class="container-fluid">
          <div class="collapse navbar-collapse" id="navbarSupportedContent">
             
            </div>
        <a class="navbar-brand text-start" href="#">Navbar</a>
        <form class="d-flex">
          <input class="form-control" type="search" placeholder="Search" aria-label="Search">
        </form>
        <div class="nav-icons text-end d-flex">
          <i class="gg-search"></i>
          <i class="gg-profile"></i>
          <i class="gg-heart"></i>
          <i class="gg-shopping-bag"></i>
         
        </div>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
          </button>
        </button>
        <!-- ------ side navbar  -->
        <!-- <aside class="sidebar">
          <div class="toggle">
              <a href="#" class="burger js-menu-toggle" data-toggle="collapse" data-target="#main-navbar">
                 <span></span>
                  </a>
            </div>
          <div class="side-inner">
    
            <div class="navbar-logoName">
              <a href="#">MANGO</a>
              <h3>Lorem ipsum <b>dolor sit.</b></h3>
    
            </div>
            <div class="manu-items">
              <a href="#">
                  <div class="category-img d-flex">
                      <p>Category Name 1</p>
                      <img src="images/categori-man.png" alt="man">
                  </div>
              </a>
            </div>
            <div class="manu-items">
              <a href="#">
                  <div class="category-img d-flex">
                      <p>Category Name 2</p>
                      <img src="images/categori-man.png" alt="man">
                  </div>
              </a>
            </div>
            <div class="manu-items">
              <a href="#">
                  <div class="category-img d-flex">
                      <p>Category Name 3</p>
                      <img src="images/categori-man.png" alt="man">
                  </div>
              </a>
            </div>
            <div class="manu-items">
              <a href="#">
                  <div class="category-img d-flex">
                      <p>Category Name 4</p>
                      <img src="images/categori-man.png" alt="man">
                  </div>
              </a>
            </div>
            <div class="manu-items">
              <a href="#">
                  <div class="category-img d-flex">
                      <p>Category Name 5</p>
                      <img src="images/categori-man.png" alt="man">
                  </div>
              </a>
            </div>
            <div class="manu-items">
              <a href="#">
                  <div class="category-img d-flex">
                      <p>Category Name 6</p>
                      <img src="images/categori-man.png" alt="man">
                  </div>
              </a>
            </div>
            <div class="manu-items">
              <a href="#">
                  <div class="category-img d-flex">
                      <p>Category Name 7</p>
                      <img src="images/categori-man.png" alt="man">
                  </div>
              </a>
            </div>
            <div class="manu-items">
              <a href="#">
                  <div class="category-img d-flex">
                      <p>Category Name 8</p>
                      <img src="images/categori-man.png" alt="man">
                  </div>
              </a>
            </div>
            <div class="manu-items">
              <a href="#">
                  <div class="category-img d-flex">
                      <p>Category Name 9</p>
                      <img src="images/categori-man.png" alt="man">
                  </div>
              </a>
            </div>

            <p class="nav-text">
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Necessitatibus, cumque!
            </p>
          </div>
          
        </aside>
      </div>
    </nav>  -->
    <!-- navbar all html end  -->
  <!-- ------------------------------------------ single-product--------------------------  -->
  <section id="product-single">
    <div class="container">
      <div class="row">
        <div class="col-lg-6">
          <div class="cart-product-img m-auto">
            <div class="cart-product-img-items">
              <img src="images/<?=$product['image']?>" alt="cart img">
            </div>
            <div class="cart-product-img-items">
              <img src="images/cart-img1.jpeg" alt="cart img">
            </div>
            <div class="cart-product-img-items">
              <img src="images/cart-img2.jpeg" alt="cart img">
            </div>
            <div class="cart-product-img-items">
              <img src="images/cart-img3.jpeg" alt="cart img">
            </div>
          </div>
        </div>
        <div class="col-lg-6">
          <div class="cart-details">
            <h1><?=$product['p_name']?> </h1>
            <span><b> $<?=$product['price']?></b></span>
            <div class="colorAndQu d-flex">
              <p>Color </p>
              <img class="" style="border-radius:50%;" id="colors" data-color="Denim_Blue@1x" src="filter/color/Denim_Blue@1x.png" height="30px" alt="color">
              <img class="" style="border-radius:50%;" id="colors" data-color="Green@1x" src="filter/color/Green@1x.png" height="30px" alt="color">
              <img class="" style="border-radius:50%;" id="colors" data-color="Grey@1x" src="filter/color/Grey@1x.png" height="30px" alt="color">
              <img class="" style="border-radius:50%;" id="colors" data-color="Navy@1x" src="filter/color/Navy@1x.png" height="30px" alt="color">
              <p class="sizee">size</p>
              <select name="size" id="" class="Quselect">
              <option value=""></option>
               <option value="xxs">XXS</option>
               <option value="xs">XS</option>
               <option value="s">S</option>
               <option value="m">M</option>
               <option value="l">L</option>
              </select>
            </div>
            
            <div class="addToCart">
              <button type="submit" id="addtocart" data-cart="<?=$product['id']?>">Add To Bag</button>
            </div>
            <div class="accordion" id="accordionExample">
              <div class="accordion-item">
                <h2 class="accordion-header" id="headingOne">
                  <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                    Accordion Item #1
                  </button>
                </h2>
                <div id="collapseOne" class="accordion-collapse collapse show" aria-labelledby="headingOne" data-bs-parent="#accordionExample">
                  <div class="accordion-body">
                    <strong>This is the first item's accordion body.</strong> It is shown by default, until the collapse plugin adds the appropriate classes that we use to style each element. These classes control the overall appearance, as well as the showing and hiding via CSS transitions. You can modify any of this with custom CSS or overriding our default variables. It's also worth noting that just about any HTML can go within the <code>.accordion-body</code>, though the transition does limit overflow.
                  </div>
                </div>
              </div>
              <div class="accordion-item">
                <h2 class="accordion-header" id="headingTwo">
                  <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                    Accordion Item #2
                  </button>
                </h2>
                <div id="collapseTwo" class="accordion-collapse collapse" aria-labelledby="headingTwo" data-bs-parent="#accordionExample">
                  <div class="accordion-body">
                    <strong>This is the second item's accordion body.</strong> It is hidden by default, until the collapse plugin adds the appropriate classes that we use to style each element. These classes control the overall appearance, as well as the showing and hiding via CSS transitions. You can modify any of this with custom CSS or overriding our default variables. It's also worth noting that just about any HTML can go within the <code>.accordion-body</code>, though the transition does limit overflow.
                  </div>
                </div>
              </div>
              <div class="accordion-item">
                <h2 class="accordion-header" id="headingThree">
                  <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                    Accordion Item #3
                  </button>
                </h2>
                <div id="collapseThree" class="accordion-collapse collapse" aria-labelledby="headingThree" data-bs-parent="#accordionExample">
                  <div class="accordion-body">
                    <strong>This is the third item's accordion body.</strong> It is hidden by default, until the collapse plugin adds the appropriate classes that we use to style each element. These classes control the overall appearance, as well as the showing and hiding via CSS transitions. You can modify any of this with custom CSS or overriding our default variables. It's also worth noting that just about any HTML can go within the <code>.accordion-body</code>, though the transition does limit overflow.
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  <!-- --------------------- footer area  -->
  <footer id="footer-area mt-3">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="pay-card text-center">
                    <i class="fa fa-paypal" aria-hidden="true"></i>
                    <i class="fa fa-cc-amex" aria-hidden="true"></i>
                    <i class="fa fa-cc-visa" aria-hidden="true"></i>
                    <i class="fa fa-cc-mastercard" aria-hidden="true"></i>
                    <i class="fa fa-credit-card-alt" aria-hidden="true"></i>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-12">
                <div class="copyright-text text-center">
                    <p>Copyright &copy; 2021 - Mengo .All Rights Reserved </p>
                </div>
            </div>
        </div>
    </div>
  </footer>

         <!-- all javascript link  -->
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery-1.12.4.min.js"></script>
    <script src="js/slick.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/custom.js"></script>
    <script src="js/addtocart.js"></script>
    <script src="js/nav.js"></script>
</body>
</html>