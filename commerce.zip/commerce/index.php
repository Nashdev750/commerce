<?php
  session_start();
  spl_autoload_register(function($class){
      include "core/".$class.".php";
  });
  
  $db = new db;

if(isset($_GET['id'])){
    $_SESSION['quiz']=array(
        "cat"=>$_GET['id'],
        "quiza"=>"",
        "quizb"=>"",
        "quizc"=>"",
        "quize"=>"",
        "quizf"=>""
    );
    header("location:quizA");
}



?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>home </title>
    <link rel="stylesheet" href="css/font-awesome.min.css">
    <link rel="stylesheet" href="css/slick.css">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/media.css">
</head>

<body>
<?php include 'partials/navbar.php';?>

    <!-- --------------bannera area  -->
    <section id="banner">
        <div class="banner-slider-main">
            <div class="banner-slider-items">
                <div class="banner-slider-content">
                    <div class="banner-overlay">
                        <h1>Lorem ipsum dolor sit amet.</h1>
                    </div>
                </div>
            </div>
            <div class="banner-slider-items">
                <div class="banner-slider-content">
                    <div class="banner-overlay">
                        <h1>Lorem ipsum dolor sit amet.</h1>
                    </div>

                </div>
            </div>
            <div class="banner-slider-items">
                <div class="banner-slider-content">
                    <div class="banner-overlay">
                        <h1>Lorem ipsum dolor sit amet.</h1>
                    </div>
                </div>
            </div>
        </div>
        <i class="fa fa-arrow-left left" aria-hidden="true"></i>
        <i class="fa fa-arrow-right right" aria-hidden="true"></i>
    </section>
<!-- how it works -->
  <div class="container con" style="width: 70%;">

  <div class="row" id="rows">
       <h3 class="text-center">How it works</h3>
       <p class="text-center">
           Start your style journey <br>
           with three simple steps
       </p><br>
       <div class="col-4">
           <div class="card">
               <div class="header">
                   <img src="images/product11 (2).jpg" alt="">
               </div>
               <div class="body">
                   <h4 class="text-center">Talk to us</h4>
                   <p class="text-center">Lorem ipsum dolor sit, amet consectetur adipisicing elit. Magnam tempore unde deserunt
                        voluptate harum at inventore quaerat esse,
                        molestias ut. Soluta, tempore. In iusto fuga error soluta illo? Error, maxime?</p>
               </div>
           </div>
       </div>
       <div class="col-4">
           <div class="card">
               <div class="header">
                   <img src="images/product11 (2).jpg" alt="">
               </div>
               <div class="body">
                   <h4 class="text-center">Talk to us</h4>
                   <p class="text-center">Lorem ipsum dolor sit, amet consectetur adipisicing elit. Magnam tempore unde deserunt
                        voluptate harum at inventore quaerat esse,
                        molestias ut. Soluta, tempore. In iusto fuga error soluta illo? Error, maxime?</p>
               </div>
           </div>
       </div>
       <div class="col-4">
           <div class="card">
               <div class="header">
                   <img src="images/product11 (2).jpg" alt="">
               </div>
               <div class="body">
                   <h4 class="text-center">Talk to us</h4>
                   <p class="text-center">Lorem ipsum dolor sit, amet consectetur adipisicing elit. Magnam tempore unde deserunt
                        voluptate harum at inventore quaerat esse,
                        molestias ut. Soluta, tempore. In iusto fuga error soluta illo? Error, maxime?</p>
               </div>
           </div>
       </div>
   </div>

   <div class="row">
       <h1 class="text-center">
           The Styles <br>
           Experts
       </h1>
       <div class="col-12">
       <section id="banner">
        <div class="banner-slider-main">
            <div class="banner-slider-items" >
                <div class="ims">
                   <div class="row" >
                       <div class="col-8">
                           <img src="images/product11 (2).jpg"  alt="">
                       </div>
                       <div class="col-4">
                           <div class="txt">
                             <p class="text-xenter p-5">
                                 Lorem ipsum dolor sit amet consectetur adipisicing elit. Debitis aut, magn
                                 i nemo aliquid dolorum molestias natus, officia quasi asperiores, excepturi saepe do
                                 lore hic ea animi accusantium in nisi voluptates fugiat.

                             </p>
                           </div>
                       </div>
                   </div>
                </div>
            </div>
            <div class="banner-slider-items">
            <div class="ims">
                   <div class="row" >
                       <div class="col-8">
                           <img src="images/product11 (2).jpg"  alt="">
                       </div>
                       <div class="col-4">
                           <div class="txt">
                             <p class="text-xenter p-5">
                                 Lorem ipsum dolor sit amet consectetur adipisicing elit. Debitis aut, magn
                                 i nemo aliquid dolorum molestias natus, officia quasi asperiores, excepturi saepe do
                                 lore hic ea animi accusantium in nisi voluptates fugiat.

                             </p>
                           </div>
                       </div>
                   </div>
                </div>
            </div>
            <div class="banner-slider-items">
            <div class="ims">
                   <div class="row" >
                       <div class="col-8">
                           <img src="images/product11 (2).jpg"  alt="">
                       </div>
                       <div class="col-4">
                           <div class="txt">
                             <p class="text-xenter p-5">
                                 Lorem ipsum dolor sit amet consectetur adipisicing elit. Debitis aut, magn
                                 i nemo aliquid dolorum molestias natus, officia quasi asperiores, excepturi saepe do
                                 lore hic ea animi accusantium in nisi voluptates fugiat.

                             </p>
                           </div>
                       </div>
                   </div>
                </div>
            </div>
        </div>
     
    </section>
       </div>
   </div>
  </div>
 

<!-- end -->
    <!-- ------------ category area  -->
    <section id="category-area">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 text-center">
                    <h2 class="mt-2 mb-3">All category </h2>
                </div>
            </div>
        </div>
        <div class="container">
            <div class="row">
                <div class="col-lg-12 cc-flex row rr">
                           <?php
                            foreach($cats as $cat){
                            ?>
                           
                        <div class="category-line-one d-flex col-3 id">
                        <div class="caregoryImg">
                            <img src="images/sliderImg.jpg" alt="">
                            <div class="overtext">
                                <h2><?=$cat['name']?> </h2>
                                <a  href="index?id=<?=$cat['id']?>">Shop Now</a>
                            </div>
                        </div>
                      
                         </div>

                            <?php
                            }
                            ?>
                   
                    <!-- <div class="category-line-one d-flex">
                        <div class="caregoryImg">
                            <img src="images/sliderImg.jpg" alt="">
                            <div class="overtext">
                                <h2>Catrgory 01 </h2>
                                <a href="#">Shop Now</a>
                            </div>
                        </div>
                        <div class="caregoryImg">
                            <img src="images/sliderImg.jpg" alt="">
                            <div class="overtext">
                                <h2>Catrgory 01 </h2>
                                <a href="#">Shop Now</a>
                            </div>
                        </div>
                    </div> -->
                </div>
            </div>
            <!-- <div class="row">
                <div class="col-lg-12 cc-flex">
                    <div class="category-line-one d-flex">
                        <div class="caregoryImg">
                            <img src="images/sliderImg.jpg" alt="">
                            <div class="overtext">
                                <h2>Catrgory 01 </h2>
                                <a href="#">Shop Now</a>
                            </div>
                        </div>
                        <div class="caregoryImg">
                            <img src="images/sliderImg.jpg" alt="">
                            <div class="overtext">
                                <h2>Catrgory 01 </h2>
                                <a href="#">Shop Now</a>
                            </div>
                        </div>
                    </div>
                    <div class="category-line-one d-flex">
                        <div class="caregoryImg">
                            <img src="images/sliderImg.jpg" alt="">
                            <div class="overtext">
                                <h2>Catrgory 01 </h2>
                                <a href="#">Shop Now</a>
                            </div>
                        </div>
                        <div class="caregoryImg">
                            <img src="images/sliderImg.jpg" alt="">
                            <div class="overtext">
                                <h2>Catrgory 01 </h2>
                                <a href="#">Shop Now</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div> -->
        </div>
    </section>
    <!-- ------------------------------ review area  -->
    <section id="review-area">
        <div class="container">
            <div class="customer-review-title">
                <h2>Customer Reviews</h2>
            </div>
            <div class="customers">
                <div class="col-12">
                    <div class="row arrow-position">
                        <div class="cus-card-main">
                            <div class="cus-card">
                                <img src="images/customer.jpg" width="100px" alt="customer">
                                <h5>s comfortable</h5>
                                <h6>Lorem ipsum dolor sit amet consectetur adipisicing elit.</h6>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star cOut"></span>
                                <span class="fa fa-star cOut"></span>
                            </div>
                            <div class="cus-card">
                                <img src="images/customer1.jpg" width="100px" alt="customer">
                                <h5>So First delivari</h5>
                                <h6>Lorem ipsum dolor sit amet consectetur adipisicing elit.</h6>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                            </div>
                            <div class="cus-card">
                                <img src="images/customer.jpg" width="100px" alt="customer">
                                <h5> comfortable</h5>
                                <h6>Lorem ipsum dolor sit amet consectetur adipisicing elit.</h6>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                            </div>
                            <div class="cus-card">
                                <img src="images/customer.jpg" width="100px" alt="customer">
                                <h5> comfortable</h5>
                                <h6>Lorem ipsum dolor sit amet consectetur adipisicing elit.</h6>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star cOut"></span>
                            </div>
                            <div class="cus-card">
                                <img src="images/customer.jpg" width="100px" alt="customer1">
                                <h5> comfortable</h5>
                                <h6>Lorem ipsum dolor sit amet consectetur adipisicing elit.</h6>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star cOut"></span>
                            </div>
                            <div class="cus-card">
                                <img src="images/customer1.jpg" width="100px" alt="customer1">
                                <h5> comfortable</h5>
                                <h6>Lorem ipsum dolor sit amet consectetur adipisicing elit.</h6>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star cOut"></span>
                                <span class="fa fa-star cOut"></span>
                            </div>
                            <div class="cus-card">
                                <img src="images/customer.jpg" width="100px" alt="customer1">
                                <h5> comfortable</h5>
                                <h6>Lorem ipsum dolor sit amet consectetur adipisicing elit.</h6>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star cOut"></span>
                                <span class="fa fa-star cOut"></span>
                            </div>
                        </div>
                        <div class="review-arrows">
                            
                        </div>
                    </div>
                </div>

            </div>
            <a href="#">More</a>
        </div>
    </section>
    <!-- ---------------------------- social area  -->
    <section id="social-area">
        <div class="container">
            <div class="row text-center">
                <div class="col-12">
                    <div class="social-icon">
                        <a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a>
                        <a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a>
                        <a href="#"><i class="fa fa-github" aria-hidden="true"></i></a>
                        <a href="#"><i class="fa fa-instagram" aria-hidden="true"></i></a>
                        <a href="#"><i class="fa fa-youtube-play" aria-hidden="true"></i></a>
                    </div>
                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Hic officiis harum aut in autem tempora?</p>
                </div>
            </div>
            <div class="row">
                <div class="col-12">
                    <div class="signup-btn">
                        <form action="#" class="frm">
                            <input type="text">
                            <input class="sub-btn" type="submit" value="Sign Up">
                        </form>
                    </div>
                </div>
                <div class="end-link">
                    <p class="mt-5"> <a href="#">Products</a> </p>
                    <hr>
                    <a href="#">About Us</a>
                    <hr>
                    <a href="#">Useful Information</a>
                    <hr>
                </div>
            </div>
        </div>
    </section>
    <!-- --------------------- footer area  -->
    <footer id="footer-area">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="pay-card text-center">
                        <i class="fa fa-paypal" aria-hidden="true"></i>
                        <i class="fa fa-cc-amex" aria-hidden="true"></i>
                        <i class="fa fa-cc-visa" aria-hidden="true"></i>
                        <i class="fa fa-cc-mastercard" aria-hidden="true"></i>
                        <i class="fa fa-credit-card-alt" aria-hidden="true"></i>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12">
                    <div class="copyright-text text-center">
                        <p>Copyright &copy; 2021 - Mengo .All Rights Reserved </p>
                    </div>
                </div>
            </div>
        </div>
    </footer>



    <!-- all javascript link  -->
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery-1.12.4.min.js"></script>
    <script src="js/slick.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/custom.js"></script>
    <script src="js/nav.js"></script>
</body>

</html>