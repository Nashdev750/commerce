
<?php
// session_start();
// spl_autoload_register(function($class){
//     include "core/".$class.".php";
// });

$db = new db;
$num = 0;
if(isset($_SESSION['cart'])){
  $sql="SELECT * FROM `cart` WHERE `cartid`='".$_SESSION['cart']."'";

  $cart = $db->readdbone($sql);
  
  $cartitms = json_decode($cart['items'],true);
  foreach($cartitms as $itm){
    $num++;
  }
}
$cats= $db->readdb("SELECT * FROM `categories`");



?>
<script type="text/javascript">
var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/60eeb8fcd6e7610a49ab376b/1fai8575f';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();
</script>
<div class="topbar">
  <div style="display: flex; justify-content: space-between;align-items: center;">
  <div class="log">
   <span></span>
   <span></span>
   <span></span>
  </div>
  <div class="logo" style="margin:0 10px">
   <a href="index"><img src="images/logo.jpeg" alt="" height="30" style="background-color: whitesmoke;"></a> 
  </div>
  </div>

  
  <ul>
  <li class="sert">
   <form action="">
     <table>
       <tr><td class="cls">X</td><td><input class="form-control" type="text" placeholder="Search"></td><td><button> <i class="gg-search"></i></button></td></tr>
     </table>
   </form>
  </li>
  <li class="no" style="width: 30px !important; min-width: 30px;"><i class="gg-search"></i></li>
   <!-- <li><a href="wishlist" style="margin-bottom: 6px;"><i class="gg-heart"></i></a><span>0</span></li> -->
   <li><a href="checkout"> <i class="gg-shopping-bag"></i></a><span class="bagitem"><?=$num?></span></li>
         
  </ul>

</div>

<div class="side">

<div class="user" style="background-color: white;border:1px solid whitesmoke">
<a href="index" style="text-decoration: none; color:black;width: 100%;"> <h5 style="width: 100%;">HOME</h5></a>
</div>
<div class="cate">
<a href="productlist" style="text-decoration: none; color:black"><h5>SHOP</h5></a>
</div>
<ul>
  <?php
  foreach($cats as $cat){
  ?>
<li><a href="index?id=<?=$cat['id']?>"><?=$cat['name']?></a> <img src="images/<?=$cat['image']?>" height="50" alt=""></li>


<?php
  }
?>
</ul>
<div class="sty">
<a href="index" style="text-decoration: none; color:black"> <h5>OUR STORY</h5></a>
</div>
</div>
<div class="over">
</div>
